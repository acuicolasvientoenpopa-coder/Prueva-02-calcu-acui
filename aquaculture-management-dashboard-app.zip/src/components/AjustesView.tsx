import React, { useState } from 'react';
import { getSavedFirebaseConfig, saveFirebaseConfig, isFirebaseConnected, FirebaseConfigData } from '../utils/firebaseService';
import { Settings, Shield, RefreshCw, Database, Sparkles, AlertCircle } from 'lucide-react';

interface AjustesViewProps {
  onResetAllData: () => void;
  onFirebaseConfigChange: () => void;
}

export const AjustesView: React.FC<AjustesViewProps> = ({ onResetAllData, onFirebaseConfigChange }) => {
  const savedConfig = getSavedFirebaseConfig();
  const [apiKey, setApiKey] = useState(savedConfig?.apiKey || '');
  const [authDomain, setAuthDomain] = useState(savedConfig?.authDomain || '');
  const [projectId, setProjectId] = useState(savedConfig?.projectId || '');
  const [storageBucket, setStorageBucket] = useState(savedConfig?.storageBucket || '');
  const [messagingSenderId, setMessagingSenderId] = useState(savedConfig?.messagingSenderId || '');
  const [appId, setAppId] = useState(savedConfig?.appId || '');

  const [statusMessage, setStatusMessage] = useState('');
  const [statusType, setStatusType] = useState<'success' | 'error' | ''>('');
  
  const isConnected = isFirebaseConnected();

  const handleSaveConfig = (e: React.FormEvent) => {
    e.preventDefault();
    setStatusMessage('');
    setStatusType('');

    if (!apiKey || !authDomain || !projectId || !appId) {
      setStatusMessage('Por favor complete al menos la API Key, Auth Domain, Project ID y App ID.');
      setStatusType('error');
      return;
    }

    const newConfig: FirebaseConfigData = {
      apiKey,
      authDomain,
      projectId,
      storageBucket,
      messagingSenderId,
      appId
    };

    saveFirebaseConfig(newConfig);
    setStatusMessage('Configuración de Firebase guardada. La aplicación intentará conectarse e iniciará sesión con sus credenciales al recargar.');
    setStatusType('success');
    
    // Trigger main reload or update auth instances
    onFirebaseConfigChange();
  };

  const handleDisconnect = () => {
    if (confirm('¿Está seguro de desconectar de Firebase y volver al modo simulación local?')) {
      saveFirebaseConfig(null);
      setApiKey('');
      setAuthDomain('');
      setProjectId('');
      setStorageBucket('');
      setMessagingSenderId('');
      setAppId('');
      setStatusMessage('Desconectado de Firebase. Volviendo a base de datos simulada en LocalStorage.');
      setStatusType('success');
      
      onFirebaseConfigChange();
    }
  };

  const handleReset = () => {
    if (confirm('¿Está seguro de restablecer la base de datos local? Esto borrará todos sus estanques, bitácoras y regresará los valores de fábrica.')) {
      onResetAllData();
      setStatusMessage('Base de datos local restablecida con éxito. Se han cargado los estanques y registros semilla.');
      setStatusType('success');
    }
  };

  return (
    <div className="space-y-8">
      {/* Header */}
      <div>
        <h2 className="text-2xl md:text-3xl font-extrabold tracking-tight text-slate-100 flex items-center gap-2.5">
          <Settings className="w-8 h-8 text-emerald-400" />
          Ajustes e Integración
        </h2>
        <p className="text-sm text-slate-400">Administre la conexión a base de datos en tiempo real y la persistencia de sus datos.</p>
      </div>

      {/* Connection Status Banner */}
      <div className={`p-5 border rounded-3xl flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 ${
        isConnected
          ? 'bg-emerald-500/10 border-emerald-500/20 text-emerald-400'
          : 'bg-amber-500/10 border-amber-500/20 text-amber-400'
      }`}>
        <div className="flex items-center gap-3">
          <Shield className="w-8 h-8 shrink-0" />
          <div>
            <h3 className="font-bold text-sm uppercase tracking-wider">
              {isConnected ? 'Base de Datos Conectada: LIVE FIREBASE' : 'Base de Datos Conectada: LOCAL SIMULATOR'}
            </h3>
            <p className="text-xs text-slate-400 mt-0.5 leading-relaxed">
              {isConnected
                ? 'Sus datos y perfiles de usuario se están sincronizando y guardando de manera segura en la nube con Firebase Firestore.'
                : 'Se encuentra utilizando el motor de simulación local de alta fidelidad. Los datos se sincronizan automáticamente en su navegador.'}
            </p>
          </div>
        </div>
        {isConnected && (
          <button
            onClick={handleDisconnect}
            className="px-4 py-2 bg-rose-500/10 border border-rose-500/20 hover:border-rose-500/40 text-rose-400 text-xs font-bold rounded-xl transition duration-200 cursor-pointer"
          >
            Desconectar
          </button>
        )}
      </div>

      {statusMessage && (
        <div className={`p-4 border rounded-xl text-xs font-semibold ${
          statusType === 'success'
            ? 'bg-emerald-500/10 border-emerald-500/25 text-emerald-400'
            : 'bg-rose-500/10 border-rose-500/25 text-rose-400'
        }`}>
          {statusMessage}
        </div>
      )}

      <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
        {/* Settings form (left columns) */}
        <div className="xl:col-span-2 bg-slate-900 border border-slate-800 rounded-3xl p-6 space-y-5">
          <h3 className="text-base font-bold text-slate-100 flex items-center gap-2 pb-3 border-b border-slate-800">
            <Database className="w-4.5 h-4.5 text-emerald-400" />
            Conectar su propio Firebase (Firestore & Auth)
          </h3>

          <form onSubmit={handleSaveConfig} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1.5">API Key</label>
                <input
                  type="text"
                  value={apiKey}
                  onChange={(e) => setApiKey(e.target.value)}
                  placeholder="AIzaSyA1..."
                  required
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-xs text-slate-300 outline-none focus:border-emerald-500/50 transition font-mono"
                />
              </div>

              <div>
                <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1.5">Auth Domain</label>
                <input
                  type="text"
                  value={authDomain}
                  onChange={(e) => setAuthDomain(e.target.value)}
                  placeholder="proyecto-123.firebaseapp.com"
                  required
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-xs text-slate-300 outline-none focus:border-emerald-500/50 transition font-mono"
                />
              </div>

              <div>
                <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1.5">Project ID</label>
                <input
                  type="text"
                  value={projectId}
                  onChange={(e) => setProjectId(e.target.value)}
                  placeholder="proyecto-123"
                  required
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-xs text-slate-300 outline-none focus:border-emerald-500/50 transition font-mono"
                />
              </div>

              <div>
                <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1.5">Storage Bucket</label>
                <input
                  type="text"
                  value={storageBucket}
                  onChange={(e) => setStorageBucket(e.target.value)}
                  placeholder="proyecto-123.appspot.com"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-xs text-slate-300 outline-none focus:border-emerald-500/50 transition font-mono"
                />
              </div>

              <div>
                <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1.5">Messaging Sender ID</label>
                <input
                  type="text"
                  value={messagingSenderId}
                  onChange={(e) => setMessagingSenderId(e.target.value)}
                  placeholder="123456789012"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-xs text-slate-300 outline-none focus:border-emerald-500/50 transition font-mono"
                />
              </div>

              <div>
                <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1.5">App ID</label>
                <input
                  type="text"
                  value={appId}
                  onChange={(e) => setAppId(e.target.value)}
                  placeholder="1:123:web:123"
                  required
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-xs text-slate-300 outline-none focus:border-emerald-500/50 transition font-mono"
                />
              </div>
            </div>

            <div className="flex justify-end pt-4 border-t border-slate-800/60">
              <button
                type="submit"
                className="px-5 py-2 bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 text-slate-950 text-sm font-bold rounded-xl shadow-lg shadow-emerald-500/10 hover:-translate-y-0.5 active:translate-y-0 transition duration-200 cursor-pointer"
              >
                Guardar y Conectar Firebase
              </button>
            </div>
          </form>
        </div>

        {/* Reset / Help Column (Right column) */}
        <div className="space-y-6">
          {/* Reset Database card */}
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 space-y-4">
            <h3 className="text-sm font-bold text-slate-400 uppercase tracking-wider flex items-center gap-2">
              <AlertCircle className="w-4.5 h-4.5 text-rose-400" />
              Zona de Peligro
            </h3>
            <p className="text-xs text-slate-550 leading-relaxed">
              Restablezca la base de datos de simulación local a sus valores de fábrica si desea re-inicializar los estanques o bitácoras por defecto.
            </p>
            <button
              onClick={handleReset}
              className="w-full py-2.5 bg-rose-550 border border-rose-500 hover:bg-rose-600 text-slate-100 text-xs font-bold rounded-xl flex items-center justify-center gap-2 transition duration-200 cursor-pointer"
            >
              <RefreshCw className="w-4 h-4" />
              Restablecer Simulador Local
            </button>
          </div>

          {/* Quick info guide */}
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 space-y-4">
            <h3 className="text-sm font-bold text-slate-400 uppercase tracking-wider flex items-center gap-2">
              <Sparkles className="w-4.5 h-4.5 text-emerald-400" />
              ¿Cómo configurar Firebase?
            </h3>
            <ul className="text-xs text-slate-550 space-y-3 leading-relaxed list-decimal list-inside font-medium">
              <li>Cree un proyecto en la consola oficial de Firebase.</li>
              <li>Habilite **Authentication** (proveedores Correo/Contraseña y Google).</li>
              <li>Habilite la base de datos **Cloud Firestore** en modo de producción o prueba.</li>
              <li>Registre una Web App en la configuración de su proyecto y copie los campos.</li>
              <li>Péguelos en el formulario lateral y guarde los cambios.</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};
