import React, { useState } from 'react';
import { Species } from '../utils/aquacultureCalculations';
import { Fish, Plus, Trash2, RefreshCw } from 'lucide-react';
import confetti from 'canvas-confetti';

interface EspeciesViewProps {
  speciesList: Species[];
  onSaveSpecies: (species: Species) => void;
  onDeleteSpecies: (id: string) => void;
  onResetToDefault: () => void;
}

export const EspeciesView: React.FC<EspeciesViewProps> = ({
  speciesList,
  onSaveSpecies,
  onDeleteSpecies,
  onResetToDefault
}) => {
  const [showAddForm, setShowAddForm] = useState(false);
  
  // Form States for Custom Species
  const [name, setName] = useState('');
  const [scientificName, setScientificName] = useState('');
  const [emoji, setEmoji] = useState('🐟');
  const [density, setDensity] = useState(10);
  const [survivalRate, setSurvivalRate] = useState(85);
  const [fcr, setFcr] = useState(1.3);
  const [feedRate, setFeedRate] = useState(3.0);
  const [feedingsPerDay, setFeedingsPerDay] = useState(3);
  const [gpd, setGpd] = useState(1.5);
  const [feedPrice, setFeedPrice] = useState(1.2);
  const [sellPrice, setSellPrice] = useState(5.0);
  const [initialWeight, setInitialWeight] = useState(5);
  const [harvestWeight, setHarvestWeight] = useState(500);
  const [workUnit, setWorkUnit] = useState<'m²' | 'm³'>('m²');

  const customSpeciesCount = speciesList.filter((s) => s.isCustom).length;

  const handleCreateSpecies = (e: React.FormEvent) => {
    e.preventDefault();
    if (customSpeciesCount >= 3) {
      alert('Límite alcanzado. Solo se permiten hasta 3 especies personalizadas.');
      return;
    }

    const newSpec: Species = {
      id: `custom-species-${Date.now()}`,
      name,
      scientificName,
      emoji,
      density,
      survivalRate,
      fcr,
      feedRate,
      feedingsPerDay,
      gpd,
      feedPrice,
      sellPrice,
      initialWeight,
      harvestWeight,
      workUnit,
      isCustom: true
    };

    onSaveSpecies(newSpec);
    confetti({ particleCount: 50, spread: 40 });
    setShowAddForm(false);
    
    // Reset fields
    setName('');
    setScientificName('');
    setEmoji('🐟');
    setDensity(10);
    setSurvivalRate(85);
    setFcr(1.3);
    setFeedRate(3.0);
    setFeedingsPerDay(3);
    setGpd(1.5);
    setFeedPrice(1.2);
    setSellPrice(5.0);
    setInitialWeight(5);
    setHarvestWeight(500);
    setWorkUnit('m²');
  };

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-2xl md:text-3xl font-extrabold tracking-tight text-slate-100">
            Configuración de Especie
          </h2>
          <p className="text-sm text-slate-400">Administre parámetros biológicos óptimos para los cálculos de su producción.</p>
        </div>
        <div className="flex items-center gap-3">
          <button
            onClick={() => {
              if (confirm('¿Está seguro de restablecer todas las especies personalizadas a los valores de fábrica?')) {
                onResetToDefault();
              }
            }}
            className="px-3.5 py-2 border border-slate-800 hover:border-slate-700 text-slate-400 hover:text-slate-200 text-sm font-bold rounded-xl flex items-center gap-2 transition duration-200 cursor-pointer"
            title="Restablecer especies"
          >
            <RefreshCw className="w-4 h-4" />
            Restablecer
          </button>
          {customSpeciesCount < 3 && (
            <button
              onClick={() => setShowAddForm(!showAddForm)}
              className="px-4 py-2 bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 text-slate-950 text-sm font-bold rounded-xl flex items-center gap-2 shadow-lg shadow-emerald-500/10 hover:shadow-emerald-400/20 hover:-translate-y-0.5 active:translate-y-0 transition duration-200 cursor-pointer"
            >
              <Plus className="w-4.5 h-4.5" />
              Nueva Especie ({customSpeciesCount}/3)
            </button>
          )}
        </div>
      </div>

      {/* Form to Add Custom Species */}
      {showAddForm && (
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-2xl">
          <h3 className="text-lg font-bold text-slate-100 mb-4 flex items-center gap-2">
            <Fish className="w-5 h-5 text-emerald-400" />
            Agregar Especie Personalizada Configurable
          </h3>
          <form onSubmit={handleCreateSpecies} className="grid grid-cols-1 md:grid-cols-4 gap-5">
            <div>
              <label className="block text-xs font-bold text-slate-400 uppercase mb-1.5">Nombre Común</label>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Ej: Bagre Canal"
                required
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-sm text-slate-200 outline-none focus:border-emerald-500/50 transition"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-400 uppercase mb-1.5">Nombre Científico</label>
              <input
                type="text"
                value={scientificName}
                onChange={(e) => setScientificName(e.target.value)}
                placeholder="Ej: Ictalurus punctatus"
                required
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-sm text-slate-200 outline-none focus:border-emerald-500/50 transition"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-400 uppercase mb-1.5">Emoji Representativo</label>
              <input
                type="text"
                value={emoji}
                onChange={(e) => setEmoji(e.target.value)}
                placeholder="Ej: 🐟, 🦐, 🦈"
                maxLength={3}
                required
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-sm text-slate-200 outline-none focus:border-emerald-500/50 transition text-center"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-400 uppercase mb-1.5">Unidad de Trabajo</label>
              <select
                value={workUnit}
                onChange={(e) => setWorkUnit(e.target.value as 'm²' | 'm³')}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-sm text-slate-200 outline-none focus:border-emerald-500/50 transition"
              >
                <option value="m²">Metro Cuadrado (m²)</option>
                <option value="m³">Metro Cúbico (m³)</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-400 uppercase mb-1.5">Densidad Sugerida (org/unidad)</label>
              <input
                type="number"
                value={density}
                onChange={(e) => setDensity(Number(e.target.value))}
                min={0.1}
                step="any"
                required
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-sm text-slate-200 outline-none focus:border-emerald-500/50 transition"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-400 uppercase mb-1.5">Supervivencia Estimada (%)</label>
              <input
                type="number"
                value={survivalRate}
                onChange={(e) => setSurvivalRate(Number(e.target.value))}
                min={1}
                max={100}
                required
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-sm text-slate-200 outline-none focus:border-emerald-500/50 transition"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-400 uppercase mb-1.5">FCR Teórico</label>
              <input
                type="number"
                value={fcr}
                onChange={(e) => setFcr(Number(e.target.value))}
                min={0.1}
                step="any"
                required
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-sm text-slate-200 outline-none focus:border-emerald-500/50 transition"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-400 uppercase mb-1.5">Tasa de Alimentación (% Biomasa)</label>
              <input
                type="number"
                value={feedRate}
                onChange={(e) => setFeedRate(Number(e.target.value))}
                min={0.1}
                step="any"
                required
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-sm text-slate-200 outline-none focus:border-emerald-500/50 transition"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-400 uppercase mb-1.5">Alimentaciones por Día</label>
              <input
                type="number"
                value={feedingsPerDay}
                onChange={(e) => setFeedingsPerDay(Number(e.target.value))}
                min={1}
                required
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-sm text-slate-200 outline-none focus:border-emerald-500/50 transition"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-400 uppercase mb-1.5">Crecimiento GPD (g/día)</label>
              <input
                type="number"
                value={gpd}
                onChange={(e) => setGpd(Number(e.target.value))}
                min={0.01}
                step="any"
                required
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-sm text-slate-200 outline-none focus:border-emerald-500/50 transition"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-400 uppercase mb-1.5">Peso de Siembra (g)</label>
              <input
                type="number"
                value={initialWeight}
                onChange={(e) => setInitialWeight(Number(e.target.value))}
                min={0.01}
                step="any"
                required
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-sm text-slate-200 outline-none focus:border-emerald-500/50 transition"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-400 uppercase mb-1.5">Peso de Cosecha (g)</label>
              <input
                type="number"
                value={harvestWeight}
                onChange={(e) => setHarvestWeight(Number(e.target.value))}
                min={0.1}
                step="any"
                required
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-sm text-slate-200 outline-none focus:border-emerald-500/50 transition"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-400 uppercase mb-1.5">Precio Alimento ($/kg)</label>
              <input
                type="number"
                value={feedPrice}
                onChange={(e) => setFeedPrice(Number(e.target.value))}
                min={0.1}
                step="any"
                required
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-sm text-slate-200 outline-none focus:border-emerald-500/50 transition"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-400 uppercase mb-1.5">Precio Venta ($/kg)</label>
              <input
                type="number"
                value={sellPrice}
                onChange={(e) => setSellPrice(Number(e.target.value))}
                min={0.1}
                step="any"
                required
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-sm text-slate-200 outline-none focus:border-emerald-500/50 transition"
              />
            </div>

            <div className="md:col-span-4 flex justify-end gap-3 pt-2">
              <button
                type="button"
                onClick={() => setShowAddForm(false)}
                className="px-4 py-2 border border-slate-800 text-slate-400 text-sm font-bold rounded-xl hover:bg-slate-800 transition cursor-pointer"
              >
                Cancelar
              </button>
              <button
                type="submit"
                className="px-5 py-2 bg-emerald-500 hover:bg-emerald-400 text-slate-950 text-sm font-bold rounded-xl transition cursor-pointer"
              >
                Guardar Especie
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Species Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {speciesList.map((spec) => (
          <div
            key={spec.id}
            className={`bg-slate-900 border rounded-3xl p-6 relative overflow-hidden transition duration-200 hover:border-slate-700 ${
              spec.isCustom ? 'border-emerald-500/20 ring-1 ring-emerald-500/5' : 'border-slate-800'
            }`}
          >
            {/* Badge for Custom Species */}
            {spec.isCustom && (
              <div className="absolute top-3 right-3 flex gap-2 items-center">
                <span className="px-2 py-0.5 bg-emerald-500/15 border border-emerald-500/35 text-emerald-400 text-[9px] font-bold rounded-full uppercase">
                  Personalizada
                </span>
                <button
                  onClick={() => {
                    if (confirm(`¿Seguro que desea eliminar la especie "${spec.name}"?`)) {
                      onDeleteSpecies(spec.id);
                    }
                  }}
                  className="p-1 bg-slate-950 border border-slate-800 hover:border-rose-500/30 text-slate-500 hover:text-rose-400 rounded-lg transition cursor-pointer"
                  title="Eliminar especie"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            )}

            {/* Emoji & Title */}
            <div className="flex items-center gap-3 mb-4">
              <span className="text-3xl p-2 bg-slate-950 border border-slate-850 rounded-2xl">{spec.emoji}</span>
              <div>
                <h3 className="font-extrabold text-slate-100 text-lg">{spec.name}</h3>
                <p className="text-xs text-slate-500 italic">{spec.scientificName}</p>
              </div>
            </div>

            {/* Parameter specifications */}
            <div className="grid grid-cols-2 gap-x-4 gap-y-3 pt-4 border-t border-slate-800/60 text-xs">
              <div>
                <span className="text-slate-500 font-medium block">Unidad de Trabajo</span>
                <span className="font-semibold text-slate-300">{spec.workUnit === 'm²' ? 'Área (m²)' : 'Volumen (m³)'}</span>
              </div>
              <div>
                <span className="text-slate-500 font-medium block">Densidad Óptima</span>
                <span className="font-semibold text-slate-300">{spec.density} org/{spec.workUnit}</span>
              </div>
              <div>
                <span className="text-slate-500 font-medium block">FCR de Referencia</span>
                <span className="font-semibold text-emerald-400 font-mono">{spec.fcr}</span>
              </div>
              <div>
                <span className="text-slate-500 font-medium block">Tasa Alimentación</span>
                <span className="font-semibold text-slate-300">{spec.feedRate}% biomasa/día</span>
              </div>
              <div>
                <span className="text-slate-500 font-medium block">Supervivencia</span>
                <span className="font-semibold text-slate-300">{spec.survivalRate}%</span>
              </div>
              <div>
                <span className="text-slate-500 font-medium block">Tasa GPD</span>
                <span className="font-semibold text-slate-300 font-mono">{spec.gpd} g/día</span>
              </div>
              <div>
                <span className="text-slate-500 font-medium block">Peso Inicial/Cosecha</span>
                <span className="font-semibold text-slate-300">{spec.initialWeight}g / {spec.harvestWeight}g</span>
              </div>
              <div>
                <span className="text-slate-500 font-medium block">Alimento/Venta</span>
                <span className="font-semibold text-slate-300">${spec.feedPrice} / ${spec.sellPrice} USD/kg</span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
