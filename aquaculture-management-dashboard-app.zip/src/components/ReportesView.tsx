import React, { useState } from 'react';
import { Pond, Species, LogEntry, calculatePondMetrics, getSpeciesThresholds, getStatus } from '../utils/aquacultureCalculations';
import { FileDown, ShieldCheck, Printer, Activity, Layers, Droplets } from 'lucide-react';

interface ReportesViewProps {
  ponds: Pond[];
  speciesList: Species[];
  logs: LogEntry[];
}

export const ReportesView: React.FC<ReportesViewProps> = ({ ponds, speciesList, logs }) => {
  const [selectedPondId, setSelectedPondId] = useState<string>(ponds[0]?.id || '');

  const activePond = ponds.find((p) => p.id === selectedPondId) || null;
  const activeSpecies = activePond ? speciesList.find((s) => s.id === activePond.speciesId) || speciesList[0] : null;
  const activeMetrics = activePond && activeSpecies ? calculatePondMetrics(activePond, activeSpecies, logs) : null;

  const pondLogs = activePond
    ? logs
        .filter((l) => l.pondId === activePond.id)
        .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())
    : [];

  const latestLog = pondLogs.length > 0 ? pondLogs[pondLogs.length - 1] : null;

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="space-y-8 print:space-y-4">
      {/* Header Banner - Hidden on Print */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 print:hidden">
        <div>
          <h2 className="text-2xl md:text-3xl font-extrabold tracking-tight text-slate-100 flex items-center gap-2.5">
            <FileDown className="w-8 h-8 text-emerald-400" />
            Reportes y Exportación
          </h2>
          <p className="text-sm text-slate-400">Genere reportes técnicos profesionales en PDF con gráficos e indicadores zootécnicos.</p>
        </div>
        
        {ponds.length > 0 && (
          <div className="flex items-end gap-3">
            <div>
              <label className="block text-[10px] font-bold text-slate-500 uppercase mb-1.5 tracking-wider">Seleccionar Estanque</label>
              <select
                value={selectedPondId}
                onChange={(e) => setSelectedPondId(e.target.value)}
                className="bg-slate-900 border border-slate-800 text-slate-200 text-sm font-bold py-2 px-4 rounded-xl focus:border-emerald-500/50 outline-none cursor-pointer"
              >
                {ponds.map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.name}
                  </option>
                ))}
              </select>
            </div>
            <button
              onClick={handlePrint}
              className="px-4 py-2 bg-emerald-505 bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 text-slate-950 text-sm font-bold rounded-xl flex items-center gap-2 shadow-lg shadow-emerald-500/10 transition duration-200 cursor-pointer"
            >
              <Printer className="w-4.5 h-4.5" />
              Imprimir / PDF
            </button>
          </div>
        )}
      </div>

      {activePond && activeSpecies && activeMetrics ? (
        <div id="report-printable-area" className="bg-slate-900 border border-slate-800 rounded-3xl p-8 print:bg-white print:text-slate-900 print:border-0 print:p-0 space-y-8 print:space-y-6">
          {/* Report Header */}
          <div className="flex justify-between items-start border-b border-slate-800 print:border-slate-200 pb-6">
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <div className="p-1.5 bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 rounded-xl print:hidden">
                  <ShieldCheck className="w-6 h-6" />
                </div>
                <h1 className="text-2xl font-extrabold text-slate-100 print:text-slate-900">
                  REPORTE TÉCNICO DE CULTIVO
                </h1>
              </div>
              <p className="text-xs text-slate-500 font-bold">
                PRUEBA 01 GPT - PLATAFORMA DE GESTIÓN ACUÍCOLA
              </p>
            </div>
            <div className="text-right text-xs text-slate-500">
              <p className="font-bold">Fecha Emisión: {new Date().toLocaleDateString()}</p>
              <p>Estanque: {activePond.name}</p>
            </div>
          </div>

          {/* Section 1: Cultivo Data & Parameters */}
          <div className="space-y-4">
            <h3 className="text-sm font-bold text-slate-300 print:text-slate-800 uppercase tracking-wider flex items-center gap-2">
              <Layers className="w-4 h-4 text-emerald-400 print:hidden" />
              1. Datos del Cultivo e Historial de Siembra
            </h3>
            
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-xs bg-slate-950/40 print:bg-slate-50 border border-slate-850 print:border-slate-200 rounded-2xl p-5">
              <div>
                <span className="text-slate-500 block font-semibold">Estanque:</span>
                <span className="font-bold text-slate-200 print:text-slate-900">{activePond.name}</span>
              </div>
              <div>
                <span className="text-slate-500 block font-semibold">Especie:</span>
                <span className="font-bold text-slate-200 print:text-slate-900">{activeSpecies.name} ({activeSpecies.scientificName})</span>
              </div>
              <div>
                <span className="text-slate-500 block font-semibold">Fecha Siembra:</span>
                <span className="font-bold text-slate-200 print:text-slate-900">{activePond.stockingDate}</span>
              </div>
              <div>
                <span className="text-slate-500 block font-semibold">Días de Cultivo:</span>
                <span className="font-bold text-slate-200 print:text-slate-900">{activeMetrics.diasCultivo} días</span>
              </div>
              <div>
                <span className="text-slate-500 block font-semibold">Área / Volumen:</span>
                <span className="font-bold text-slate-200 print:text-slate-900">{activePond.area} m² / {activePond.volume} m³</span>
              </div>
              <div>
                <span className="text-slate-500 block font-semibold">Densidad Siembra:</span>
                <span className="font-bold text-slate-200 print:text-slate-900">{activePond.density} org/{activeSpecies.workUnit}</span>
              </div>
              <div>
                <span className="text-slate-500 block font-semibold">Población Inicial:</span>
                <span className="font-bold text-slate-200 print:text-slate-900">{activeMetrics.totalOrganismsInitial.toLocaleString()} org</span>
              </div>
              <div>
                <span className="text-slate-500 block font-semibold">Población Actual:</span>
                <span className="font-bold text-slate-200 print:text-slate-900">{activeMetrics.totalOrganismsCurrent.toLocaleString()} org</span>
              </div>
            </div>
          </div>

          {/* Section 2: Zootechnical Indicators */}
          <div className="space-y-4">
            <h3 className="text-sm font-bold text-slate-300 print:text-slate-800 uppercase tracking-wider flex items-center gap-2">
              <Activity className="w-4 h-4 text-emerald-400 print:hidden" />
              2. Indicadores Zootécnicos y de Control Biológico
            </h3>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 text-xs">
              <div className="bg-slate-950/25 print:bg-slate-50 border border-slate-850 print:border-slate-200 p-4 rounded-xl text-center">
                <span className="text-slate-500 block font-semibold mb-1">SGR (Growth Rate)</span>
                <span className="text-lg font-extrabold text-slate-100 print:text-slate-900 font-mono">{activeMetrics.sgr}%/día</span>
              </div>
              <div className="bg-slate-950/25 print:bg-slate-50 border border-slate-850 print:border-slate-200 p-4 rounded-xl text-center">
                <span className="text-slate-500 block font-semibold mb-1">GPD Real (Crec. Diario)</span>
                <span className="text-lg font-extrabold text-slate-100 print:text-slate-900 font-mono">{activeMetrics.gpdReal} g/día</span>
              </div>
              <div className="bg-slate-950/25 print:bg-slate-50 border border-slate-850 print:border-slate-200 p-4 rounded-xl text-center">
                <span className="text-slate-500 block font-semibold mb-1">Supervivencia / Mortalidad</span>
                <span className="text-lg font-extrabold text-emerald-400 print:text-emerald-600 font-mono">
                  {activeMetrics.supervivenciaPorcentaje.toFixed(1)}% / {activeMetrics.mortalidadPorcentaje.toFixed(1)}%
                </span>
              </div>
              <div className="bg-slate-950/25 print:bg-slate-50 border border-slate-850 print:border-slate-200 p-4 rounded-xl text-center">
                <span className="text-slate-500 block font-semibold mb-1">Productividad Obtenida</span>
                <span className="text-lg font-extrabold text-slate-100 print:text-slate-900 font-mono">{activeMetrics.productividadArea} kg/{activeSpecies.workUnit}</span>
              </div>
              <div className="bg-slate-950/25 print:bg-slate-50 border border-slate-850 print:border-slate-200 p-4 rounded-xl text-center">
                <span className="text-slate-500 block font-semibold mb-1">Uniformidad de Lote</span>
                <span className="text-lg font-extrabold text-slate-100 print:text-slate-900 font-mono">{activePond.uniformity || 85}%</span>
              </div>
              <div className="bg-slate-950/25 print:bg-slate-50 border border-slate-850 print:border-slate-200 p-4 rounded-xl text-center">
                <span className="text-slate-500 block font-semibold mb-1">Coef. Variación (CV%)</span>
                <span className="text-lg font-extrabold text-slate-100 print:text-slate-900 font-mono">{activePond.cv || 7}%</span>
              </div>
              <div className="bg-slate-950/25 print:bg-slate-50 border border-slate-850 print:border-slate-200 p-4 rounded-xl text-center">
                <span className="text-slate-500 block font-semibold mb-1">FCR Teórico</span>
                <span className="text-lg font-extrabold text-slate-100 print:text-slate-900 font-mono">{activeSpecies.fcr}</span>
              </div>
              <div className="bg-slate-950/25 print:bg-slate-50 border border-slate-850 print:border-slate-200 p-4 rounded-xl text-center">
                <span className="text-slate-500 block font-semibold mb-1">FCR Real Obtenido</span>
                <span className="text-lg font-extrabold text-slate-100 print:text-slate-900 font-mono">{activeMetrics.fcrReal}</span>
              </div>
            </div>
          </div>

          {/* Section 3: Water Quality Statistics */}
          <div className="space-y-4">
            <h3 className="text-sm font-bold text-slate-300 print:text-slate-800 uppercase tracking-wider flex items-center gap-2">
              <Droplets className="w-4 h-4 text-emerald-400 print:hidden" />
              3. Calidad del Agua y Parámetros Químicos Recientes
            </h3>

            {latestLog && latestLog.waterQuality ? (
              <div className="overflow-x-auto border border-slate-850 print:border-slate-200 rounded-2xl">
                <table className="w-full text-left text-xs border-collapse bg-slate-950/15 print:bg-white">
                  <thead>
                    <tr className="border-b border-slate-800 print:border-slate-200 bg-slate-950/30 print:bg-slate-50 text-slate-500 font-bold">
                      <th className="p-3">Parámetro</th>
                      <th className="p-3">Valor Leído</th>
                      <th className="p-3">Rango Óptimo</th>
                      <th className="p-3">Estado</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-850 print:divide-slate-200">
                    {(() => {
                      const wq = latestLog.waterQuality!;
                      const thresholds = getSpeciesThresholds(activePond.speciesId);
                      const params = [
                        { name: 'Oxígeno Disuelto', val: wq.oxygen, unit: 'mg/L', range: thresholds.oxygen },
                        { name: 'Temperatura', val: wq.temperature, unit: '°C', range: thresholds.temperature },
                        { name: 'Nivel de pH', val: wq.ph, unit: '', range: thresholds.ph },
                        { name: 'Amonio (NH4+)', val: wq.ammonium, unit: 'mg/L', range: thresholds.ammonium },
                        { name: 'Nitrito (NO2-)', val: wq.nitrite, unit: 'mg/L', range: thresholds.nitrite },
                        { name: 'Nitrato (NO3-)', val: wq.nitrate, unit: 'mg/L', range: thresholds.nitrate },
                        { name: 'Salinidad', val: wq.salinity, unit: 'ppt', range: thresholds.salinity }
                      ];

                      return params.map((p, idx) => {
                        const status = getStatus(p.val, p.range);
                        return (
                          <tr key={idx}>
                            <td className="p-3 font-medium text-slate-300 print:text-slate-700">{p.name}</td>
                            <td className="p-3 font-bold text-slate-200 print:text-slate-900 font-mono">{p.val} {p.unit}</td>
                            <td className="p-3 text-slate-400 font-mono">{p.range.minOpt} - {p.range.maxOpt} {p.unit}</td>
                            <td className="p-3">
                              <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-bold ${
                                status === 'optimo'
                                  ? 'text-emerald-400 bg-emerald-500/10'
                                  : status === 'precaucion'
                                  ? 'text-amber-400 bg-amber-500/10'
                                  : 'text-rose-400 bg-rose-500/10'
                              }`}>
                                {status.toUpperCase()}
                              </span>
                            </td>
                          </tr>
                        );
                      });
                    })()}
                  </tbody>
                </table>
              </div>
            ) : (
              <p className="text-xs text-slate-500 italic p-4 border border-dashed border-slate-800 print:border-slate-200 rounded-xl text-center bg-slate-950/15">
                No hay mediciones químicas registradas para este estanque en la bitácora.
              </p>
            )}
          </div>

          {/* Section 4: Production, Costs & Financial Profitability */}
          <div className="space-y-4 page-break-before">
            <h3 className="text-sm font-bold text-slate-300 print:text-slate-800 uppercase tracking-wider flex items-center gap-2">
              <span className="print:hidden">💵</span>
              4. Rendimiento Comercial, Biomasa y Costos
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
              <div className="bg-slate-950/45 print:bg-slate-50 border border-slate-850 print:border-slate-200 rounded-2xl p-5 flex justify-between items-center">
                <div>
                  <span className="text-slate-500 block text-[10px] font-bold uppercase">Biomasa Producida</span>
                  <span className="text-2xl font-extrabold text-slate-100 print:text-slate-900 font-mono">{activeMetrics.biomasaActualKg.toLocaleString(undefined, { maximumFractionDigits: 0 })} kg</span>
                </div>
                <span className="text-slate-600 text-sm">Muestreo prom: {activePond.currentWeight || activeSpecies.harvestWeight} g</span>
              </div>

              <div className="bg-slate-950/45 print:bg-slate-50 border border-slate-850 print:border-slate-200 rounded-2xl p-5 flex justify-between items-center">
                <div>
                  <span className="text-slate-500 block text-[10px] font-bold uppercase">Inversión Alimento</span>
                  <span className="text-2xl font-extrabold text-slate-100 print:text-slate-900 font-mono">${activeMetrics.costoAlimentoUsd.toLocaleString(undefined, { maximumFractionDigits: 0 })} USD</span>
                </div>
                <span className="text-slate-600 text-sm">Precio: ${activeSpecies.feedPrice}/kg</span>
              </div>

              <div className="bg-slate-950/45 print:bg-slate-50 border border-slate-850 print:border-slate-200 rounded-2xl p-5 flex justify-between items-center">
                <div>
                  <span className="text-emerald-500 block text-[10px] font-bold uppercase">Utilidad Estimada</span>
                  <span className="text-2xl font-extrabold text-emerald-400 print:text-emerald-600 font-mono">${activeMetrics.utilidadEstimadaUsd.toLocaleString(undefined, { maximumFractionDigits: 0 })} USD</span>
                </div>
                <span className="text-slate-600 text-sm">Venta: ${activeSpecies.sellPrice}/kg</span>
              </div>
            </div>
          </div>

          {/* Printable Signature Line (Only visible on print) */}
          <div className="hidden print:flex justify-between items-end pt-16">
            <div className="border-t border-slate-300 w-48 text-center pt-2 text-[10px] text-slate-500 font-bold">
              Firma del Técnico
            </div>
            <div className="border-t border-slate-300 w-48 text-center pt-2 text-[10px] text-slate-500 font-bold">
              Firma del Productor / Institución
            </div>
          </div>
        </div>
      ) : (
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-12 text-center print:bg-white">
          <FileDown className="w-14 h-14 text-slate-700 mx-auto mb-4" />
          <h3 className="text-lg font-bold text-slate-300 print:text-slate-700">Cree un estanque para ver sus reportes</h3>
          <p className="text-xs text-slate-500 mt-1">Genere resúmenes ejecutivos listos para imprimir y guardar en PDF.</p>
        </div>
      )}
    </div>
  );
};
