import React, { useState } from 'react';
import { Pond, Species, LogEntry, calculatePondMetrics } from '../utils/aquacultureCalculations';
import { Layers, Plus, Trash2, Target, ChevronRight, LineChart } from 'lucide-react';

interface PondsViewProps {
  ponds: Pond[];
  speciesList: Species[];
  logs: LogEntry[];
  onSavePond: (pond: Pond) => void;
  onDeletePond: (id: string) => void;
  selectedPondId: string | null;
  setSelectedPondId: (id: string | null) => void;
}

export const PondsView: React.FC<PondsViewProps> = ({
  ponds,
  speciesList,
  logs,
  onSavePond,
  onDeletePond,
  selectedPondId,
  setSelectedPondId
}) => {
  const [showAddForm, setShowAddForm] = useState(false);
  const [name, setName] = useState('');
  const [area, setArea] = useState(1000);
  const [volume, setVolume] = useState(1500);
  const [speciesId, setSpeciesId] = useState(speciesList[0]?.id || 'tilapia');
  const [stockingDate, setStockingDate] = useState(new Date().toISOString().split('T')[0]);
  const [density, setDensity] = useState(15);
  const [initialWeight, setInitialWeight] = useState(5);

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    const selectedSpec = speciesList.find((s) => s.id === speciesId) || speciesList[0];
    const newPond: Pond = {
      id: `pond-${Date.now()}`,
      name,
      area,
      volume,
      speciesId,
      stockingDate,
      density,
      initialWeight: initialWeight || selectedSpec.initialWeight || 5,
      currentWeight: initialWeight || 5,
      mortalidadesAcumuladas: 0,
      alimentacionAcumulada: 0,
      uniformity: 90,
      cv: 5
    };
    onSavePond(newPond);
    setName('');
    setShowAddForm(false);
    setSelectedPondId(newPond.id);
  };

  const activePond = ponds.find((p) => p.id === selectedPondId) || null;
  const activeSpecies = activePond ? speciesList.find((s) => s.id === activePond.speciesId) || speciesList[0] : null;
  const activeMetrics = activePond && activeSpecies ? calculatePondMetrics(activePond, activeSpecies, logs) : null;

  // Sorted logs for selected pond
  const pondLogs = activePond
    ? logs
        .filter((l) => l.pondId === activePond.id)
        .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())
    : [];

  // SVG Chart helper
  const renderSvgChart = (
    title: string,
    data: { x: string; y: number }[],
    color: string,
    yUnit: string
  ) => {
    if (data.length === 0) {
      return (
        <div className="h-48 flex items-center justify-center border border-slate-800 bg-slate-950/50 rounded-xl">
          <p className="text-xs text-slate-600">No hay registros suficientes para graficar esta métrica.</p>
        </div>
      );
    }

    const padding = 40;
    const width = 500;
    const height = 220;

    const xMax = width - padding * 2;
    const yMax = height - padding * 2;

    const minVal = 0;
    const maxVal = Math.max(...data.map((d) => d.y)) * 1.2 || 10;

    const points = data.map((d, i) => {
      const x = padding + (i / Math.max(1, data.length - 1)) * xMax;
      const y = height - padding - ((d.y - minVal) / (maxVal - minVal)) * yMax;
      return { x, y, val: d.y, date: d.x };
    });

    let pathD = '';
    if (points.length > 0) {
      pathD = `M ${points[0].x} ${points[0].y} ` + points.slice(1).map((p) => `L ${p.x} ${p.y}`).join(' ');
    }

    return (
      <div className="bg-slate-950/80 border border-slate-800/60 rounded-2xl p-4">
        <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-3">{title}</h4>
        <svg viewBox={`0 0 ${width} ${height}`} className="w-full h-auto">
          {/* Grid Lines */}
          {[0, 0.25, 0.5, 0.75, 1].map((ratio, idx) => {
            const y = padding + ratio * yMax;
            const val = maxVal - ratio * (maxVal - minVal);
            return (
              <g key={idx}>
                <line
                  x1={padding}
                  y1={y}
                  x2={width - padding}
                  y2={y}
                  stroke="#1e293b"
                  strokeDasharray="3 3"
                />
                <text
                  x={padding - 8}
                  y={y + 3}
                  fill="#64748b"
                  fontSize="9"
                  textAnchor="end"
                  className="font-mono"
                >
                  {val.toFixed(val > 100 ? 0 : 1)}
                </text>
              </g>
            );
          })}

          {/* X-axis Labels (Dates) */}
          {points.map((p, i) => {
            // Show only first, middle, and last to avoid overlap
            if (i === 0 || i === points.length - 1 || (points.length > 2 && i === Math.floor(points.length / 2))) {
              return (
                <text
                  key={i}
                  x={p.x}
                  y={height - 12}
                  fill="#64748b"
                  fontSize="9"
                  textAnchor="middle"
                  className="font-mono"
                >
                  {p.date.split('-').slice(1).join('/')}
                </text>
              );
            }
            return null;
          })}

          {/* Smooth Line */}
          {pathD && (
            <path
              d={pathD}
              fill="none"
              stroke={color}
              strokeWidth="2.5"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          )}

          {/* Data Points with tooltips */}
          {points.map((p, i) => (
            <g key={i} className="group cursor-pointer">
              <circle
                cx={p.x}
                cy={p.y}
                r="4"
                fill={color}
                stroke="#0f172a"
                strokeWidth="1.5"
                className="transition duration-150 hover:r-6"
              />
              <text
                x={p.x}
                y={p.y - 10}
                fill="#f1f5f9"
                fontSize="9"
                fontWeight="bold"
                textAnchor="middle"
                className="opacity-0 group-hover:opacity-100 bg-slate-900 transition-opacity px-1 py-0.5 rounded pointer-events-none font-mono"
              >
                {p.val.toFixed(p.val > 100 ? 0 : 1)} {yUnit}
              </text>
            </g>
          ))}
        </svg>
      </div>
    );
  };

  return (
    <div className="space-y-8">
      {/* Header bar */}
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl md:text-3xl font-extrabold tracking-tight text-slate-100">
            Gestión de Estanques
          </h2>
          <p className="text-sm text-slate-400">Controle el inventario, crecimiento biológico y curvas zootécnicas.</p>
        </div>
        <button
          onClick={() => setShowAddForm(!showAddForm)}
          className="px-4 py-2 bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 text-slate-950 text-sm font-bold rounded-xl flex items-center gap-2 shadow-lg shadow-emerald-500/10 hover:shadow-emerald-400/20 hover:-translate-y-0.5 active:translate-y-0 transition duration-200 cursor-pointer"
        >
          <Plus className="w-4.5 h-4.5" />
          Nuevo Estanque
        </button>
      </div>

      {/* Add Pond Form Modal/Collapse */}
      {showAddForm && (
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-2xl">
          <h3 className="text-lg font-bold text-slate-100 mb-4 flex items-center gap-2">
            <Layers className="w-5 h-5 text-emerald-400" />
            Registrar Nuevo Estanque de Cultivo
          </h3>
          <form onSubmit={handleCreate} className="grid grid-cols-1 md:grid-cols-3 gap-5">
            <div>
              <label className="block text-xs font-bold text-slate-400 uppercase mb-1.5">
                Nombre / Identificador
              </label>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Ej: Estanque Norte-3"
                required
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-sm text-slate-200 placeholder-slate-600 focus:border-emerald-500/50 transition outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-400 uppercase mb-1.5">
                Especie Sembrada
              </label>
              <select
                value={speciesId}
                onChange={(e) => setSpeciesId(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-sm text-slate-200 focus:border-emerald-500/50 transition outline-none"
              >
                {speciesList.map((spec) => (
                  <option key={spec.id} value={spec.id}>
                    {spec.emoji} {spec.name} ({spec.scientificName})
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-400 uppercase mb-1.5">
                Fecha de Siembra
              </label>
              <input
                type="date"
                value={stockingDate}
                onChange={(e) => setStockingDate(e.target.value)}
                required
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-sm text-slate-200 focus:border-emerald-500/50 transition outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-400 uppercase mb-1.5">
                Área Útil (m²)
              </label>
              <input
                type="number"
                value={area}
                onChange={(e) => setArea(Number(e.target.value))}
                min={1}
                required
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-sm text-slate-200 focus:border-emerald-500/50 transition outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-400 uppercase mb-1.5">
                Volumen Útil (m³)
              </label>
              <input
                type="number"
                value={volume}
                onChange={(e) => setVolume(Number(e.target.value))}
                min={1}
                required
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-sm text-slate-200 focus:border-emerald-500/50 transition outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-400 uppercase mb-1.5">
                Densidad Inicial (org/unidad)
              </label>
              <input
                type="number"
                value={density}
                onChange={(e) => setDensity(Number(e.target.value))}
                min={0.1}
                step="any"
                required
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-sm text-slate-200 focus:border-emerald-500/50 transition outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-400 uppercase mb-1.5">
                Peso Inicial Promedio (g)
              </label>
              <input
                type="number"
                value={initialWeight}
                onChange={(e) => setInitialWeight(Number(e.target.value))}
                min={0.01}
                step="any"
                required
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-sm text-slate-200 focus:border-emerald-500/50 transition outline-none"
              />
            </div>

            <div className="md:col-span-3 flex justify-end gap-3 pt-2">
              <button
                type="button"
                onClick={() => setShowAddForm(false)}
                className="px-4 py-2 border border-slate-800 text-slate-400 text-sm font-bold rounded-xl hover:bg-slate-800 transition"
              >
                Cancelar
              </button>
              <button
                type="submit"
                className="px-5 py-2 bg-emerald-500 hover:bg-emerald-400 text-slate-950 text-sm font-bold rounded-xl transition"
              >
                Guardar Estanque
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Ponds Grid and Detail side-by-side */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Left list column */}
        <div className="lg:col-span-1 space-y-3">
          <h3 className="text-xs font-bold text-slate-500 uppercase tracking-wider">Lista de Estanques</h3>
          {ponds.length === 0 ? (
            <p className="text-xs text-slate-500 py-4 text-center">Sin estanques.</p>
          ) : (
            ponds.map((p) => {
              const spec = speciesList.find((s) => s.id === p.speciesId) || speciesList[0];
              const isActive = selectedPondId === p.id;
              return (
                <button
                  key={p.id}
                  onClick={() => setSelectedPondId(p.id)}
                  className={`w-full text-left p-3.5 rounded-xl border flex items-center justify-between transition duration-200 group cursor-pointer ${
                    isActive
                      ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400'
                      : 'bg-slate-900 border-slate-800 hover:border-slate-700 text-slate-300'
                  }`}
                >
                  <div className="min-w-0 flex-1">
                    <p className={`font-bold text-sm truncate ${isActive ? 'text-emerald-400' : 'text-slate-200 group-hover:text-emerald-400'}`}>
                      {p.name}
                    </p>
                    <span className="text-[10px] text-slate-500 font-medium block mt-0.5">
                      {spec.emoji} {spec.name}
                    </span>
                  </div>
                  <ChevronRight className={`w-4 h-4 shrink-0 transition-transform ${isActive ? 'text-emerald-400 translate-x-0.5' : 'text-slate-600'}`} />
                </button>
              );
            })
          )}
        </div>

        {/* Right detail column */}
        <div className="lg:col-span-3">
          {activePond && activeSpecies && activeMetrics ? (
            <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 space-y-8">
              {/* Detail Header */}
              <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 pb-6 border-b border-slate-800">
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-2xl">{activeSpecies.emoji}</span>
                    <h3 className="text-xl font-extrabold text-slate-100">{activePond.name}</h3>
                  </div>
                  <p className="text-xs text-slate-500 font-medium">
                    Especie: <span className="text-slate-300 font-bold">{activeSpecies.name}</span> ({activeSpecies.scientificName}) | Siembra: {activePond.stockingDate}
                  </p>
                </div>
                <div className="flex items-center gap-2.5">
                  <button
                    onClick={() => {
                      if (confirm(`¿Está seguro de eliminar el estanque "${activePond.name}"? Se eliminarán sus bitácoras asociadas.`)) {
                        onDeletePond(activePond.id);
                        setSelectedPondId(null);
                      }
                    }}
                    className="p-2.5 bg-rose-500/10 border border-rose-500/20 hover:border-rose-500/45 text-rose-400 rounded-xl transition cursor-pointer"
                    title="Eliminar estanque"
                  >
                    <Trash2 className="w-4.5 h-4.5" />
                  </button>
                </div>
              </div>

              {/* Zootechnical Parameters Panel */}
              <div>
                <h4 className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-4 flex items-center gap-1.5">
                  <Target className="w-4 h-4 text-emerald-400" /> Parámetros Zootécnicos Actuales
                </h4>
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
                  <div className="bg-slate-950/60 border border-slate-800/60 rounded-xl p-3">
                    <p className="text-[10px] text-slate-500 font-bold uppercase mb-1">SGR (%/día)</p>
                    <p className="text-lg font-extrabold text-slate-200 font-mono">{activeMetrics.sgr}%</p>
                  </div>
                  <div className="bg-slate-950/60 border border-slate-800/60 rounded-xl p-3">
                    <p className="text-[10px] text-slate-500 font-bold uppercase mb-1">GPD (g/día)</p>
                    <p className="text-lg font-extrabold text-slate-200 font-mono">{activeMetrics.gpdReal} g</p>
                  </div>
                  <div className="bg-slate-950/60 border border-slate-800/60 rounded-xl p-3">
                    <p className="text-[10px] text-slate-500 font-bold uppercase mb-1">FCR Teórico</p>
                    <p className="text-lg font-extrabold text-slate-200 font-mono">{activeSpecies.fcr}</p>
                  </div>
                  <div className="bg-slate-950/60 border border-slate-800/60 rounded-xl p-3">
                    <p className="text-[10px] text-slate-500 font-bold uppercase mb-1">FCR Real</p>
                    <p className={`text-lg font-extrabold font-mono ${
                      activeMetrics.fcrReal <= activeSpecies.fcr ? 'text-emerald-400' : 'text-amber-400'
                    }`}>{activeMetrics.fcrReal || 'N/D'}</p>
                  </div>
                  <div className="bg-slate-950/60 border border-slate-800/60 rounded-xl p-3">
                    <p className="text-[10px] text-slate-500 font-bold uppercase mb-1">Mortalidad Acum.</p>
                    <p className="text-lg font-extrabold text-rose-400 font-mono">
                      {activeMetrics.mortalidadPorcentaje.toFixed(1)}%
                    </p>
                  </div>
                  <div className="bg-slate-950/60 border border-slate-800/60 rounded-xl p-3">
                    <p className="text-[10px] text-slate-500 font-bold uppercase mb-1">Supervivencia Real</p>
                    <p className="text-lg font-extrabold text-emerald-400 font-mono">
                      {activeMetrics.supervivenciaPorcentaje.toFixed(1)}%
                    </p>
                  </div>
                  <div className="bg-slate-950/60 border border-slate-800/60 rounded-xl p-3">
                    <p className="text-[10px] text-slate-500 font-bold uppercase mb-1">Productividad</p>
                    <p className="text-lg font-extrabold text-slate-200 font-mono">
                      {activeMetrics.productividadArea} <span className="text-[10px] text-slate-500 font-medium">kg/{activeSpecies.workUnit}</span>
                    </p>
                  </div>
                  <div className="bg-slate-950/60 border border-slate-800/60 rounded-xl p-3">
                    <p className="text-[10px] text-slate-500 font-bold uppercase mb-1">Biomasa Actual</p>
                    <p className="text-lg font-extrabold text-slate-200 font-mono">
                      {activeMetrics.biomasaActualKg.toLocaleString(undefined, { maximumFractionDigits: 0 })} <span className="text-[10px] text-slate-500 font-medium">kg</span>
                    </p>
                  </div>
                  <div className="bg-slate-950/60 border border-slate-800/60 rounded-xl p-3">
                    <p className="text-[10px] text-slate-500 font-bold uppercase mb-1">Biomasa Proyectada</p>
                    <p className="text-lg font-extrabold text-slate-200 font-mono">
                      {activeMetrics.biomasaFinalKg.toLocaleString(undefined, { maximumFractionDigits: 0 })} <span className="text-[10px] text-slate-500 font-medium">kg</span>
                    </p>
                  </div>
                  <div className="bg-slate-950/60 border border-slate-800/60 rounded-xl p-3">
                    <p className="text-[10px] text-slate-500 font-bold uppercase mb-1">Uniformidad</p>
                    <p className="text-lg font-extrabold text-slate-200 font-mono">{activePond.uniformity || 85}%</p>
                  </div>
                  <div className="bg-slate-950/60 border border-slate-800/60 rounded-xl p-3">
                    <p className="text-[10px] text-slate-500 font-bold uppercase mb-1">Coef. Variación (CV)</p>
                    <p className="text-lg font-extrabold text-slate-200 font-mono">{activePond.cv || 7}%</p>
                  </div>
                  <div className="bg-slate-950/60 border border-slate-800/60 rounded-xl p-3">
                    <p className="text-[10px] text-slate-500 font-bold uppercase mb-1">Días de Cultivo</p>
                    <p className="text-lg font-extrabold text-slate-200 font-mono">{activeMetrics.diasCultivo} d</p>
                  </div>
                </div>
              </div>

              {/* Graphs Section */}
              <div>
                <h4 className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-4 flex items-center gap-1.5">
                  <LineChart className="w-4.5 h-4.5 text-emerald-400" /> Historial y Gráficos Dinámicos
                </h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                  {renderSvgChart(
                    'Peso Promedio vs Tiempo (g)',
                    pondLogs
                      .filter((l) => l.avgWeightSample !== undefined && l.avgWeightSample > 0)
                      .map((l) => ({ x: l.date, y: l.avgWeightSample || 0 })),
                    '#10b981',
                    'g'
                  )}

                  {renderSvgChart(
                    'Biomasa Estimada vs Tiempo (kg)',
                    pondLogs
                      .filter((l) => l.avgWeightSample !== undefined && l.avgWeightSample > 0)
                      .map((l) => {
                        // Compute biomass for that historical log
                        const orgs = activeMetrics.totalOrganismsInitial - pondLogs.filter(history => new Date(history.date).getTime() <= new Date(l.date).getTime()).reduce((sum, history) => sum + history.mortalities, 0);
                        const biomass = (orgs * (l.avgWeightSample || 0)) / 1000;
                        return { x: l.date, y: biomass };
                      }),
                    '#3b82f6',
                    'kg'
                  )}

                  {renderSvgChart(
                    'Mortalidad Acumulada (orgs)',
                    pondLogs.map((l, idx) => {
                      const cumMort = pondLogs.slice(0, idx + 1).reduce((sum, history) => sum + history.mortalities, 0);
                      return { x: l.date, y: cumMort };
                    }),
                    '#f43f5e',
                    'org'
                  )}

                  {renderSvgChart(
                    'FCR Real Acumulado',
                    pondLogs
                      .filter((l) => l.avgWeightSample !== undefined && l.avgWeightSample > 0)
                      .map((l, idx) => {
                        const cumFeed = pondLogs.slice(0, idx + 1).reduce((sum, history) => sum + history.feedAmount, 0);
                        const orgs = activeMetrics.totalOrganismsInitial - pondLogs.slice(0, idx + 1).reduce((sum, history) => sum + history.mortalities, 0);
                        const biomassActual = (orgs * (l.avgWeightSample || 0)) / 1000;
                        const biomassInit = (activeMetrics.totalOrganismsInitial * (activePond.initialWeight || activeSpecies.initialWeight)) / 1000;
                        const gain = Math.max(1, biomassActual - biomassInit);
                        return { x: l.date, y: cumFeed / gain };
                      }),
                    '#fbbf24',
                    ''
                  )}
                </div>
              </div>
            </div>
          ) : (
            <div className="bg-slate-900 border border-slate-800 rounded-3xl p-12 text-center">
              <Layers className="w-14 h-14 text-slate-700 mx-auto mb-4" />
              <h3 className="text-lg font-bold text-slate-300">Seleccione un estanque</h3>
              <p className="text-xs text-slate-500 mt-1">Elija un estanque del listado lateral para visualizar su control biológico.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
