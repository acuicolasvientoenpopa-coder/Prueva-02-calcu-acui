import React, { useState } from 'react';
import { Pond, Species, LogEntry, getSpeciesThresholds, getStatus, Range } from '../utils/aquacultureCalculations';
import { Droplets, Thermometer, Wind, Hash, CheckCircle, AlertTriangle, AlertCircle, HelpCircle } from 'lucide-react';

interface WaterQualityViewProps {
  ponds: Pond[];
  speciesList: Species[];
  logs: LogEntry[];
}

export const WaterQualityView: React.FC<WaterQualityViewProps> = ({ ponds, speciesList, logs }) => {
  const [selectedPondId, setSelectedPondId] = useState<string>(ponds[0]?.id || '');

  const activePond = ponds.find((p) => p.id === selectedPondId) || null;
  const activeSpecies = activePond ? speciesList.find((s) => s.id === activePond.speciesId) || speciesList[0] : null;
  
  // Get latest log with water quality data
  const pondLogs = activePond
    ? logs
        .filter((l) => l.pondId === activePond.id && l.waterQuality !== undefined)
        .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
    : [];
  
  const latestLog = pondLogs[0] || null;
  const wq = latestLog?.waterQuality || null;
  const thresholds = activePond ? getSpeciesThresholds(activePond.speciesId) : null;

  const renderMetricCard = (
    name: string,
    value: number | undefined,
    range: Range | undefined,
    unit: string,
    description: string,
    icon: React.ReactNode
  ) => {
    if (value === undefined || !range) {
      return (
        <div className="bg-slate-950/40 border border-slate-800/50 rounded-2xl p-4 flex flex-col justify-between h-40">
          <div className="flex justify-between items-start">
            <span className="text-xs font-bold text-slate-500 uppercase">{name}</span>
            <span className="text-slate-600">{icon}</span>
          </div>
          <p className="text-xs text-slate-600 italic">Sin lecturas recientes registradas en la bitácora.</p>
        </div>
      );
    }

    const status = getStatus(value, range);
    
    // Styling based on status
    let statusColor = 'text-emerald-400 bg-emerald-500/10 border-emerald-500/20';
    let statusText = 'Óptimo';
    let DotColor = 'bg-emerald-400';
    let borderGlow = 'hover:border-emerald-500/30';

    if (status === 'precaucion') {
      statusColor = 'text-amber-400 bg-amber-500/10 border-amber-500/20';
      statusText = 'Precaución';
      DotColor = 'bg-amber-400';
      borderGlow = 'hover:border-amber-500/30';
    } else if (status === 'critico') {
      statusColor = 'text-rose-400 bg-rose-500/10 border-rose-500/20';
      statusText = 'Crítico';
      DotColor = 'bg-rose-400';
      borderGlow = 'hover:border-rose-500/30';
    }

    // Calculate indicator position on the progress bar
    const minVal = Math.min(range.minWarn, value) * 0.8;
    const maxVal = Math.max(range.maxWarn, value) * 1.2;
    const percent = ((value - minVal) / (maxVal - minVal)) * 100;
    const safeStartPercent = ((range.minOpt - minVal) / (maxVal - minVal)) * 100;
    const safeEndPercent = ((range.maxOpt - minVal) / (maxVal - minVal)) * 100;

    return (
      <div className={`bg-slate-900 border border-slate-800/85 rounded-2xl p-5 flex flex-col justify-between h-48 transition-colors duration-300 ${borderGlow}`}>
        {/* Top Info */}
        <div>
          <div className="flex justify-between items-start">
            <div className="space-y-0.5">
              <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">{name}</span>
              <span className="block text-[10px] text-slate-500 font-medium">{description}</span>
            </div>
            <div className="p-1.5 bg-slate-950 rounded-lg border border-slate-800 text-slate-400">
              {icon}
            </div>
          </div>

          {/* Value and Status */}
          <div className="flex items-baseline justify-between mt-3">
            <p className="text-2xl font-extrabold text-slate-100 font-mono tracking-tight">
              {value}
              <span className="text-xs font-medium text-slate-500 ml-1">{unit}</span>
            </p>
            <span className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold border ${statusColor}`}>
              <span className={`w-1 h-1 rounded-full ${DotColor} animate-pulse`} />
              {statusText}
            </span>
          </div>
        </div>

        {/* Progress Slider (Meter Bar) */}
        <div className="mt-4 space-y-1.5">
          <div className="h-1.5 w-full bg-slate-950 rounded-full relative overflow-hidden">
            {/* Safe/Optimal Area highlight */}
            <div
              className="absolute h-full bg-emerald-500/20"
              style={{ left: `${Math.max(0, safeStartPercent)}%`, width: `${Math.max(5, safeEndPercent - safeStartPercent)}%` }}
            />
            {/* Current Pointer */}
            <div
              className={`absolute h-full w-1.5 rounded-full ${
                status === 'optimo' ? 'bg-emerald-400' : status === 'precaucion' ? 'bg-amber-400' : 'bg-rose-400'
              }`}
              style={{ left: `${Math.max(0, Math.min(98, percent))}%` }}
            />
          </div>
          <div className="flex justify-between text-[9px] text-slate-500 font-semibold">
            <span>Rango Óptimo: {range.minOpt} - {range.maxOpt} {unit}</span>
            <span>Leído: {latestLog ? latestLog.date.split('-').slice(1).join('/') : ''}</span>
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="space-y-8">
      {/* Header Banner */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-2xl md:text-3xl font-extrabold tracking-tight text-slate-100 flex items-center gap-2.5">
            <Droplets className="w-8 h-8 text-emerald-400" />
            Calidad de Agua
          </h2>
          <p className="text-sm text-slate-400">Verifique en tiempo real los niveles físico-químicos óptimos de cada cultivo.</p>
        </div>
        
        {/* Select Estanque */}
        {ponds.length > 0 && (
          <div>
            <label className="block text-[10px] font-bold text-slate-500 uppercase mb-1.5 tracking-wider">Seleccionar Estanque</label>
            <select
              value={selectedPondId}
              onChange={(e) => setSelectedPondId(e.target.value)}
              className="bg-slate-900 border border-slate-800 hover:border-slate-700 text-slate-200 text-sm font-bold py-2 px-4 rounded-xl focus:border-emerald-500/50 outline-none cursor-pointer"
            >
              {ponds.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.name}
                </option>
              ))}
            </select>
          </div>
        )}
      </div>

      {activePond && activeSpecies && thresholds ? (
        <div className="space-y-6">
          {/* Status Info Banner */}
          <div className="p-5 bg-slate-900 border border-slate-850 rounded-3xl flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
            <div>
              <p className="text-xs font-bold text-slate-400">
                Estanque Activo: <span className="text-emerald-400 font-extrabold">{activePond.name}</span>
              </p>
              <p className="text-xs text-slate-500 mt-0.5">
                Especie de Referencia: <span className="text-slate-300 font-semibold">{activeSpecies.name}</span> ({activeSpecies.scientificName})
              </p>
            </div>
            {latestLog ? (
              <div className="text-xs text-slate-400 font-medium">
                Último Registro Físico-Químico: <span className="text-slate-200 font-bold">{latestLog.date}</span>
              </div>
            ) : (
              <div className="text-xs text-slate-500 font-semibold">
                ⚠️ No hay lecturas de calidad de agua cargadas para este estanque. ¡Cree una bitácora!
              </div>
            )}
          </div>

          {/* Indicators Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
            {renderMetricCard(
              'Oxígeno Disuelto',
              wq?.oxygen,
              thresholds.oxygen,
              'mg/L',
              'Esencial para la respiración de los organismos.',
              <Wind className="w-4.5 h-4.5" />
            )}

            {renderMetricCard(
              'Temperatura',
              wq?.temperature,
              thresholds.temperature,
              '°C',
              'Influye en el metabolismo y tasa de alimentación.',
              <Thermometer className="w-4.5 h-4.5" />
            )}

            {renderMetricCard(
              'Nivel de pH',
              wq?.ph,
              thresholds.ph,
              '',
              'Mide el grado de acidez o alcalinidad del agua.',
              <Hash className="w-4.5 h-4.5" />
            )}

            {renderMetricCard(
              'Amonio (NH4+)',
              wq?.ammonium,
              thresholds.ammonium,
              'mg/L',
              'Tóxico en concentraciones elevadas. Desecho orgánico.',
              <AlertCircle className="w-4.5 h-4.5" />
            )}

            {renderMetricCard(
              'Nitrito (NO2-)',
              wq?.nitrite,
              thresholds.nitrite,
              'mg/L',
              'Subproducto intermedio de nitrificación, muy tóxico.',
              <AlertTriangle className="w-4.5 h-4.5" />
            )}

            {renderMetricCard(
              'Nitrato (NO3-)',
              wq?.nitrate,
              thresholds.nitrate,
              'mg/L',
              'Menos tóxico, asimilado por fitoplancton y algas.',
              <CheckCircle className="w-4.5 h-4.5" />
            )}

            {renderMetricCard(
              'Alcalinidad',
              wq?.alkalinity,
              thresholds.alkalinity,
              'mg/L',
              'Capacidad amortiguadora para resistir cambios de pH.',
              <HelpCircle className="w-4.5 h-4.5" />
            )}

            {renderMetricCard(
              'Dureza Total',
              wq?.hardness,
              thresholds.hardness,
              'mg/L',
              'Concentración de iones de calcio y magnesio.',
              <CheckCircle className="w-4.5 h-4.5" />
            )}

            {renderMetricCard(
              'Salinidad',
              wq?.salinity,
              thresholds.salinity,
              'ppt',
              'Concentración de sales disueltas, vital para camarones.',
              <Wind className="w-4.5 h-4.5" />
            )}

            {renderMetricCard(
              'Transparencia',
              wq?.transparency,
              thresholds.transparency,
              'cm',
              'Indica la abundancia del fitoplancton (Disco Secchi).',
              <Wind className="w-4.5 h-4.5" />
            )}
          </div>
        </div>
      ) : (
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-12 text-center">
          <Droplets className="w-14 h-14 text-slate-700 mx-auto mb-4" />
          <h3 className="text-lg font-bold text-slate-300">Cree un estanque para comenzar</h3>
          <p className="text-xs text-slate-500 mt-1">Los indicadores de calidad del agua requieren un estanque activo con una especie seleccionada.</p>
        </div>
      )}
    </div>
  );
};
