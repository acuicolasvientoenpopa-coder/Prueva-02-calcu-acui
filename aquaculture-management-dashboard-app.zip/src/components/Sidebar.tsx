import React from 'react';
import { AppUser } from '../utils/firebaseService';
import {
  LayoutDashboard,
  Layers,
  Calculator,
  Fish,
  Droplets,
  BookOpen,
  FileDown,
  Settings,
  LogOut,
  Menu,
  X
} from 'lucide-react';

interface SidebarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  user: AppUser;
  onLogout: () => void;
  isMobileOpen: boolean;
  setIsMobileOpen: (open: boolean) => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeTab,
  setActiveTab,
  user,
  onLogout,
  isMobileOpen,
  setIsMobileOpen
}) => {
  const menuItems = [
    { id: 'dashboard', name: 'Dashboard', icon: LayoutDashboard },
    { id: 'estanques', name: 'Estanques', icon: Layers },
    { id: 'calculadora', name: 'Calculadora', icon: Calculator },
    { id: 'especies', name: 'Especies', icon: Fish },
    { id: 'calidad', name: 'Calidad de Agua', icon: Droplets },
    { id: 'bitacora', name: 'Bitácora', icon: BookOpen },
    { id: 'reportes', name: 'Reportes PDF', icon: FileDown },
    { id: 'ajustes', name: 'Ajustes Firebase', icon: Settings }
  ];

  const handleNav = (tabId: string) => {
    setActiveTab(tabId);
    setIsMobileOpen(false);
  };

  const sidebarContent = (
    <div className="flex flex-col h-full bg-slate-900 border-r border-slate-800 text-slate-300">
      {/* Brand Header */}
      <div className="h-20 flex items-center gap-3 px-6 border-b border-slate-800/80">
        <div className="p-2 bg-emerald-500/10 border border-emerald-500/20 rounded-xl text-emerald-400">
          <Fish className="w-6 h-6 animate-pulse" />
        </div>
        <div>
          <h2 className="font-extrabold text-slate-100 text-lg tracking-tight leading-none">
            Prueba 01 GPT
          </h2>
          <span className="text-[10px] font-semibold tracking-widest text-emerald-400 uppercase mt-1 block">
            Acuicultura SaaS
          </span>
        </div>
      </div>

      {/* Profile Box */}
      <div className="p-4 border-b border-slate-800/80 bg-slate-950/30">
        <div className="flex items-center gap-3">
          <img
            src={user.photoURL || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150'}
            alt={user.displayName}
            className="w-11 h-11 rounded-xl border border-slate-700 object-cover"
          />
          <div className="min-w-0 flex-1">
            <p className="font-bold text-slate-200 text-sm truncate">{user.displayName}</p>
            <p className="text-[11px] text-slate-500 truncate">{user.email}</p>
            <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[9px] font-bold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 mt-1">
              Técnico Principal
            </span>
          </div>
        </div>
      </div>

      {/* Navigation Menu */}
      <nav className="flex-1 px-3 py-4 space-y-1 overflow-y-auto scrollbar-thin">
        {menuItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => handleNav(item.id)}
              className={`w-full flex items-center gap-3.5 px-4 py-3 rounded-xl text-sm font-semibold transition duration-200 group cursor-pointer ${
                isActive
                  ? 'bg-emerald-500/10 border border-emerald-500/25 text-emerald-400 shadow-sm'
                  : 'hover:bg-slate-800/50 hover:text-slate-200 border border-transparent'
              }`}
            >
              <Icon
                className={`w-5 h-5 transition-transform duration-300 group-hover:scale-105 ${
                  isActive ? 'text-emerald-400' : 'text-slate-400 group-hover:text-slate-200'
                }`}
              />
              {item.name}
            </button>
          );
        })}
      </nav>

      {/* Logout Box */}
      <div className="p-4 border-t border-slate-800/80">
        <button
          onClick={onLogout}
          className="w-full flex items-center gap-3.5 px-4 py-3 rounded-xl text-sm font-semibold text-rose-400 hover:bg-rose-500/10 hover:border-rose-500/20 border border-transparent transition duration-200 cursor-pointer"
        >
          <LogOut className="w-5 h-5 text-rose-400" />
          Cerrar Sesión
        </button>
      </div>
    </div>
  );

  return (
    <>
      {/* Mobile topbar bar */}
      <header className="lg:hidden h-16 bg-slate-900 border-b border-slate-800 px-4 flex items-center justify-between fixed top-0 left-0 right-0 z-40">
        <div className="flex items-center gap-3">
          <div className="p-1.5 bg-emerald-500/10 border border-emerald-500/20 rounded-lg text-emerald-400">
            <Fish className="w-5 h-5" />
          </div>
          <h1 className="font-bold text-slate-100 text-base tracking-tight">Prueba 01 GPT</h1>
        </div>
        <button
          onClick={() => setIsMobileOpen(!isMobileOpen)}
          className="p-2 hover:bg-slate-800 rounded-lg text-slate-400 hover:text-slate-200 transition duration-200 cursor-pointer"
        >
          {isMobileOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
        </button>
      </header>

      {/* Mobile drawer backdrop */}
      {isMobileOpen && (
        <div
          onClick={() => setIsMobileOpen(false)}
          className="lg:hidden fixed inset-0 bg-black/60 backdrop-blur-sm z-40 transition-opacity"
        />
      )}

      {/* Mobile drawer */}
      <aside
        className={`lg:hidden fixed top-16 bottom-0 left-0 w-72 z-40 transition-transform duration-300 ease-in-out transform ${
          isMobileOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        {sidebarContent}
      </aside>

      {/* Desktop Sidebar */}
      <aside className="hidden lg:block w-72 h-screen sticky top-0 shrink-0 z-30">
        {sidebarContent}
      </aside>
    </>
  );
};
