import React, { useState } from 'react';
import { authService, AppUser } from '../utils/firebaseService';
import { Mail, Lock, ShieldCheck, User, ArrowRight } from 'lucide-react';
import confetti from 'canvas-confetti';

interface AuthModalProps {
  onAuthSuccess: (user: AppUser) => void;
}

export const AuthModal: React.FC<AuthModalProps> = ({ onAuthSuccess }) => {
  const [isRegister, setIsRegister] = useState(false);
  const [isForgot, setIsForgot] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [displayName, setDisplayName] = useState('');
  const [error, setError] = useState('');
  const [message, setMessage] = useState('');
  const [loading, setLoading] = useState(false);

  const handleEmailAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setMessage('');
    setLoading(true);

    try {
      if (isForgot) {
        const res = await authService.recoverPassword(email);
        if (res.success) {
          setMessage('Se ha enviado un correo de recuperación. Revise su bandeja de entrada.');
        } else {
          setError(res.error || 'Ocurrió un error al enviar el correo.');
        }
      } else if (isRegister) {
        const res = await authService.registerWithEmail(email, password, displayName);
        if (res.user) {
          confetti({ particleCount: 100, spread: 70, origin: { y: 0.6 } });
          onAuthSuccess(res.user);
        } else {
          setError(res.error || 'Error al crear la cuenta.');
        }
      } else {
        const res = await authService.loginWithEmail(email, password);
        if (res.user) {
          confetti({ particleCount: 80, spread: 60, origin: { y: 0.6 } });
          onAuthSuccess(res.user);
        } else {
          setError(res.error || 'Usuario o contraseña incorrectos.');
        }
      }
    } catch (err) {
      setError('Ocurrió un error inesperado.');
    } finally {
      setLoading(false);
    }
  };

  const handleGoogleAuth = async () => {
    setError('');
    setLoading(true);
    try {
      const res = await authService.loginWithGoogle();
      if (res.user) {
        confetti({ particleCount: 100, spread: 70, origin: { y: 0.6 } });
        onAuthSuccess(res.user);
      } else {
        setError(res.error || 'Error con el inicio de sesión de Google.');
      }
    } catch (err) {
      setError('Ocurrió un error al conectar con Google.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-slate-950 relative overflow-hidden px-4 py-12">
      {/* Background Decorative Glows */}
      <div className="absolute top-[-10%] left-[-10%] w-[50%] h-[50%] rounded-full bg-emerald-500/10 blur-[120px] pointer-events-none" />
      <div className="absolute bottom-[-10%] right-[-10%] w-[50%] h-[50%] rounded-full bg-blue-500/10 blur-[120px] pointer-events-none" />

      <div className="w-full max-w-md z-10">
        {/* Header Logo / Title */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center p-3 bg-emerald-500/10 border border-emerald-500/20 rounded-2xl mb-4">
            <ShieldCheck className="w-10 h-10 text-emerald-400" />
          </div>
          <h1 className="text-3xl font-extrabold tracking-tight text-slate-100">
            Prueba 01 GPT
          </h1>
          <p className="mt-2 text-sm text-slate-400 font-medium">
            Plataforma Profesional de Control y Gestión Acuícola
          </p>
        </div>

        {/* Auth Card Container */}
        <div className="bg-slate-900/80 backdrop-blur-xl border border-slate-800 p-8 rounded-3xl shadow-2xl shadow-slate-950/50">
          <h2 className="text-xl font-bold text-slate-100 mb-6">
            {isForgot
              ? 'Recuperar contraseña'
              : isRegister
              ? 'Crear cuenta profesional'
              : 'Iniciar sesión'}
          </h2>

          {error && (
            <div className="mb-4 p-3.5 bg-rose-500/10 border border-rose-500/25 text-rose-400 rounded-xl text-xs font-medium">
              {error}
            </div>
          )}

          {message && (
            <div className="mb-4 p-3.5 bg-emerald-500/10 border border-emerald-500/25 text-emerald-400 rounded-xl text-xs font-medium">
              {message}
            </div>
          )}

          <form onSubmit={handleEmailAuth} className="space-y-4">
            {isRegister && !isForgot && (
              <div>
                <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1.5">
                  Nombre Completo
                </label>
                <div className="relative">
                  <User className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
                  <input
                    type="text"
                    value={displayName}
                    onChange={(e) => setDisplayName(e.target.value)}
                    placeholder="Ej: Carlos Mendoza"
                    required
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-10 pr-4 py-2.5 text-sm text-slate-200 placeholder-slate-600 focus:border-emerald-500/50 focus:ring-1 focus:ring-emerald-500/30 transition duration-200 outline-none"
                  />
                </div>
              </div>
            )}

            <div>
              <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1.5">
                Correo Electrónico
              </label>
              <div className="relative">
                <Mail className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="carlos@empresa.com"
                  required
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-10 pr-4 py-2.5 text-sm text-slate-200 placeholder-slate-600 focus:border-emerald-500/50 focus:ring-1 focus:ring-emerald-500/30 transition duration-200 outline-none"
                />
              </div>
            </div>

            {!isForgot && (
              <div>
                <div className="flex justify-between items-center mb-1.5">
                  <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider">
                    Contraseña
                  </label>
                  {!isRegister && (
                    <button
                      type="button"
                      onClick={() => {
                        setIsForgot(true);
                        setError('');
                        setMessage('');
                      }}
                      className="text-xs font-semibold text-emerald-400 hover:text-emerald-300 transition-colors"
                    >
                      ¿Olvidó su contraseña?
                    </button>
                  )}
                </div>
                <div className="relative">
                  <Lock className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
                  <input
                    type="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••"
                    required
                    minLength={6}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-10 pr-4 py-2.5 text-sm text-slate-200 placeholder-slate-600 focus:border-emerald-500/50 focus:ring-1 focus:ring-emerald-500/30 transition duration-200 outline-none"
                  />
                </div>
              </div>
            )}

            <button
              type="submit"
              disabled={loading}
              className="w-full bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 text-slate-950 font-bold py-2.5 px-4 rounded-xl text-sm flex items-center justify-center gap-2 shadow-lg shadow-emerald-500/15 hover:shadow-emerald-400/25 hover:-translate-y-0.5 active:translate-y-0 transition duration-200 disabled:opacity-50 disabled:pointer-events-none cursor-pointer"
            >
              {loading ? (
                <div className="w-5 h-5 border-2 border-slate-950 border-t-transparent rounded-full animate-spin" />
              ) : (
                <>
                  {isForgot ? 'Enviar instrucciones' : isRegister ? 'Crear mi cuenta' : 'Iniciar sesión'}
                  <ArrowRight className="w-4 h-4" />
                </>
              )}
            </button>
          </form>

          {/* Divider */}
          {!isForgot && (
            <>
              <div className="my-6 flex items-center">
                <div className="flex-grow border-t border-slate-800" />
                <span className="px-3 text-xs text-slate-500 uppercase tracking-wider font-medium">o continuar con</span>
                <div className="flex-grow border-t border-slate-800" />
              </div>

              <button
                onClick={handleGoogleAuth}
                disabled={loading}
                className="w-full bg-slate-950 hover:bg-slate-900 text-slate-300 font-semibold py-2.5 px-4 border border-slate-800 hover:border-slate-700 rounded-xl text-sm flex items-center justify-center gap-2.5 transition duration-200 active:translate-y-0 cursor-pointer"
              >
                <svg className="w-4 h-4 mr-1" viewBox="0 0 24 24">
                  <path
                    fill="#EA4335"
                    d="M12.24 10.285V14.4h6.887c-.648 2.41-2.519 4.114-5.136 4.114-3.355 0-6.075-2.72-6.075-6.075s2.72-6.075 6.075-6.075c1.496 0 2.862.543 3.924 1.437l3.023-3.023C18.882 2.13 15.78 1 12.24 1 6.144 1 1.2 5.944 1.2 12s4.944 11 11.04 11c6.36 0 10.575-4.473 10.575-10.777 0-.726-.065-1.43-.188-2.116H12.24z"
                  />
                </svg>
                Google
              </button>
            </>
          )}

          {/* Mode Switch */}
          <div className="mt-6 text-center">
            {isForgot ? (
              <button
                onClick={() => {
                  setIsForgot(false);
                  setError('');
                  setMessage('');
                }}
                className="text-xs font-semibold text-slate-400 hover:text-slate-300 transition-colors"
              >
                Volver al inicio de sesión
              </button>
            ) : (
              <button
                onClick={() => {
                  setIsRegister(!isRegister);
                  setError('');
                  setMessage('');
                }}
                className="text-xs font-semibold text-slate-400 hover:text-slate-300 transition-colors"
              >
                {isRegister
                  ? '¿Ya tienes una cuenta? Inicia sesión'
                  : '¿Eres nuevo? Crea tu cuenta aquí'}
              </button>
            )}
          </div>
        </div>

        {/* Footer note */}
        <div className="mt-6 text-center">
          <p className="text-xs text-slate-600">
            Para demostraciones inmediatas, cualquier contraseña de 6 dígitos es aceptada de manera segura.
          </p>
        </div>
      </div>
    </div>
  );
};
