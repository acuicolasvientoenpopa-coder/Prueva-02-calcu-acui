import React, { useState, useEffect } from 'react';
import { Species } from '../utils/aquacultureCalculations';
import { Calculator, Info, Activity } from 'lucide-react';

interface CalculadoraViewProps {
  speciesList: Species[];
}

export const CalculadoraView: React.FC<CalculadoraViewProps> = ({ speciesList }) => {
  const [selectedSpeciesId, setSelectedSpeciesId] = useState(speciesList[0]?.id || 'tilapia');
  
  // Inputs
  const [size, setSize] = useState(1000); // m² or m³
  const [density, setDensity] = useState(15);
  const [survival, setSurvival] = useState(85); // %
  const [fcr, setFcr] = useState(1.3);
  const [initialWeight, setInitialWeight] = useState(5); // g
  const [harvestWeight, setHarvestWeight] = useState(500); // g
  const [feedPrice, setFeedPrice] = useState(1.2); // USD/kg
  const [sellPrice, setSellPrice] = useState(4.5); // USD/kg
  
  // Species GPD
  const [gpd, setGpd] = useState(1.8);
  const [workUnit, setWorkUnit] = useState<'m²' | 'm³'>('m²');

  // Load default values when species changes
  useEffect(() => {
    const spec = speciesList.find((s) => s.id === selectedSpeciesId);
    if (spec) {
      setDensity(spec.density);
      setSurvival(spec.survivalRate);
      setFcr(spec.fcr);
      setInitialWeight(spec.initialWeight);
      setHarvestWeight(spec.harvestWeight);
      setFeedPrice(spec.feedPrice);
      setSellPrice(spec.sellPrice);
      setGpd(spec.gpd);
      setWorkUnit(spec.workUnit);
    }
  }, [selectedSpeciesId, speciesList]);

  // CALCULATIONS
  const totalOrganismsInitial = Math.round(density * size);
  const totalOrganismsHarvest = Math.round(totalOrganismsInitial * (survival / 100));
  const totalMortality = totalOrganismsInitial - totalOrganismsHarvest;

  const biomasaInicialKg = (totalOrganismsInitial * initialWeight) / 1000;
  const biomasaFinalKg = (totalOrganismsHarvest * harvestWeight) / 1000;
  const gananciaBiomasaKg = Math.max(0, biomasaFinalKg - biomasaInicialKg);

  const alimentoTotalKg = gananciaBiomasaKg * fcr;
  const costoAlimentoUsd = alimentoTotalKg * feedPrice;
  const ingresoBrutoUsd = biomasaFinalKg * sellPrice;
  const utilidadEstimadaUsd = ingresoBrutoUsd - costoAlimentoUsd;

  const productividadFinal = size > 0 ? biomasaFinalKg / size : 0;
  const diasCultivoEstimados = gpd > 0 ? Math.ceil((harvestWeight - initialWeight) / gpd) : 0;

  return (
    <div className="space-y-8">
      {/* Header */}
      <div>
        <h2 className="text-2xl md:text-3xl font-extrabold tracking-tight text-slate-100">
          Calculadora de Producción
        </h2>
        <p className="text-sm text-slate-400">Simule densidades de siembra, rendimientos biológicos y proyecciones de rentabilidad.</p>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
        {/* Controls panel (Left column) */}
        <div className="xl:col-span-1 bg-slate-900 border border-slate-800 rounded-3xl p-6 space-y-5">
          <div className="flex items-center gap-2 pb-3 border-b border-slate-800">
            <Calculator className="w-5 h-5 text-emerald-400" />
            <h3 className="font-bold text-slate-100">Parámetros de Simulación</h3>
          </div>

          {/* Species Selection */}
          <div>
            <label className="block text-xs font-bold text-slate-400 uppercase mb-1.5">
              Especie de Referencia
            </label>
            <select
              value={selectedSpeciesId}
              onChange={(e) => setSelectedSpeciesId(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-sm text-slate-200 focus:border-emerald-500/50 outline-none"
            >
              {speciesList.map((spec) => (
                <option key={spec.id} value={spec.id}>
                  {spec.emoji} {spec.name}
                </option>
              ))}
            </select>
          </div>

          {/* Slider Inputs */}
          <div className="space-y-4">
            <div>
              <div className="flex justify-between text-xs font-semibold mb-1">
                <span className="text-slate-400">Tamaño del Estanque ({workUnit})</span>
                <span className="text-emerald-400 font-mono font-bold">{size.toLocaleString()}</span>
              </div>
              <input
                type="range"
                min="10"
                max="10000"
                step="50"
                value={size}
                onChange={(e) => setSize(Number(e.target.value))}
                className="w-full accent-emerald-500 cursor-pointer"
              />
            </div>

            <div>
              <div className="flex justify-between text-xs font-semibold mb-1">
                <span className="text-slate-400">Densidad ({totalOrganismsInitial.toLocaleString()} org)</span>
                <span className="text-emerald-400 font-mono font-bold">{density} org/{workUnit}</span>
              </div>
              <input
                type="range"
                min="1"
                max="100"
                step="1"
                value={density}
                onChange={(e) => setDensity(Number(e.target.value))}
                className="w-full accent-emerald-500 cursor-pointer"
              />
            </div>

            <div>
              <div className="flex justify-between text-xs font-semibold mb-1">
                <span className="text-slate-400">Supervivencia Esperada (%)</span>
                <span className="text-emerald-400 font-mono font-bold">{survival}%</span>
              </div>
              <input
                type="range"
                min="30"
                max="100"
                step="1"
                value={survival}
                onChange={(e) => setSurvival(Number(e.target.value))}
                className="w-full accent-emerald-500 cursor-pointer"
              />
            </div>

            <div>
              <div className="flex justify-between text-xs font-semibold mb-1">
                <span className="text-slate-400">FCR Esperado</span>
                <span className="text-emerald-400 font-mono font-bold">{fcr}</span>
              </div>
              <input
                type="range"
                min="0.8"
                max="3.0"
                step="0.05"
                value={fcr}
                onChange={(e) => setFcr(Number(e.target.value))}
                className="w-full accent-emerald-500 cursor-pointer"
              />
            </div>
          </div>

          {/* Numerical input fields */}
          <div className="grid grid-cols-2 gap-4 pt-2 border-t border-slate-800">
            <div>
              <label className="block text-[10px] font-bold text-slate-500 uppercase mb-1">Peso Inicial (g)</label>
              <input
                type="number"
                value={initialWeight}
                onChange={(e) => setInitialWeight(Number(e.target.value))}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-1.5 text-xs text-slate-200 font-mono outline-none"
              />
            </div>
            <div>
              <label className="block text-[10px] font-bold text-slate-500 uppercase mb-1">Peso Cosecha (g)</label>
              <input
                type="number"
                value={harvestWeight}
                onChange={(e) => setHarvestWeight(Number(e.target.value))}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-1.5 text-xs text-slate-200 font-mono outline-none"
              />
            </div>
            <div>
              <label className="block text-[10px] font-bold text-slate-500 uppercase mb-1">Precio Alimento ($/kg)</label>
              <input
                type="number"
                value={feedPrice}
                onChange={(e) => setFeedPrice(Number(e.target.value))}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-1.5 text-xs text-slate-200 font-mono outline-none"
              />
            </div>
            <div>
              <label className="block text-[10px] font-bold text-slate-500 uppercase mb-1">Precio Venta ($/kg)</label>
              <input
                type="number"
                value={sellPrice}
                onChange={(e) => setSellPrice(Number(e.target.value))}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-1.5 text-xs text-slate-200 font-mono outline-none"
              />
            </div>
            <div className="col-span-2">
              <label className="block text-[10px] font-bold text-slate-500 uppercase mb-1">Tasa GPD Real (g/día)</label>
              <input
                type="number"
                value={gpd}
                onChange={(e) => setGpd(Number(e.target.value))}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-1.5 text-xs text-slate-200 font-mono outline-none"
              />
            </div>
          </div>
        </div>

        {/* Output calculations panel (Right columns) */}
        <div className="xl:col-span-2 space-y-6">
          {/* Projections Dashboard */}
          <div className="bg-gradient-to-b from-slate-900 to-slate-950 border border-slate-800 rounded-3xl p-6">
            <h3 className="text-base font-bold text-slate-100 flex items-center gap-2 mb-6">
              <Activity className="w-4.5 h-4.5 text-emerald-400" />
              Rendimiento y Resultados Estimados
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-5 mb-8">
              {/* Biomasa Final */}
              <div className="bg-slate-950 border border-slate-800/80 rounded-2xl p-4.5">
                <p className="text-[10px] font-bold tracking-wider text-slate-500 uppercase mb-1.5">Biomasa Final Proyectada</p>
                <div className="flex items-baseline gap-1">
                  <span className="text-2xl font-extrabold text-slate-100 tracking-tight">{biomasaFinalKg.toLocaleString(undefined, { maximumFractionDigits: 1 })}</span>
                  <span className="text-xs font-medium text-slate-500">kg</span>
                </div>
                <span className="text-[10px] text-slate-400 block mt-1.5 font-medium">
                  Inicial: {biomasaInicialKg.toFixed(1)} kg
                </span>
              </div>

              {/* Alimento Necesario */}
              <div className="bg-slate-950 border border-slate-800/80 rounded-2xl p-4.5">
                <p className="text-[10px] font-bold tracking-wider text-slate-500 uppercase mb-1.5">Alimento Total Requerido</p>
                <div className="flex items-baseline gap-1">
                  <span className="text-2xl font-extrabold text-slate-100 tracking-tight">{alimentoTotalKg.toLocaleString(undefined, { maximumFractionDigits: 1 })}</span>
                  <span className="text-xs font-medium text-slate-500">kg</span>
                </div>
                <span className="text-[10px] text-slate-400 block mt-1.5 font-medium">
                  Costo: ${costoAlimentoUsd.toLocaleString(undefined, { maximumFractionDigits: 0 })} USD
                </span>
              </div>

              {/* Utilidad Estimada */}
              <div className="bg-slate-950 border border-emerald-500/20 rounded-2xl p-4.5 relative overflow-hidden">
                <div className="absolute top-0 right-0 w-16 h-16 bg-emerald-500/5 rounded-full blur-lg pointer-events-none" />
                <p className="text-[10px] font-bold tracking-wider text-emerald-500 uppercase mb-1.5">Utilidad Neta Estimada</p>
                <div className="flex items-baseline gap-0.5">
                  <span className="text-2xl font-extrabold text-emerald-400 tracking-tight">${utilidadEstimadaUsd.toLocaleString(undefined, { maximumFractionDigits: 0 })}</span>
                  <span className="text-[10px] font-medium text-emerald-600">USD</span>
                </div>
                <span className="text-[10px] text-emerald-500/80 block mt-1.5 font-bold">
                  Ingreso: ${ingresoBrutoUsd.toLocaleString(undefined, { maximumFractionDigits: 0 })} USD
                </span>
              </div>
            </div>

            {/* Technical specs checklist */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 pt-6 border-t border-slate-800/60">
              <div className="text-center md:text-left">
                <span className="block text-[10px] font-semibold text-slate-500 uppercase">Población Final</span>
                <span className="text-base font-extrabold text-slate-200 font-mono">{totalOrganismsHarvest.toLocaleString()}</span>
                <span className="block text-[9px] text-slate-500 mt-0.5">Mortalidad: {totalMortality.toLocaleString()}</span>
              </div>
              <div className="text-center md:text-left">
                <span className="block text-[10px] font-semibold text-slate-500 uppercase">Productividad</span>
                <span className="text-base font-extrabold text-slate-200 font-mono">{productividadFinal.toFixed(2)} kg/{workUnit}</span>
                <span className="block text-[9px] text-slate-500 mt-0.5">Capacidad de carga</span>
              </div>
              <div className="text-center md:text-left">
                <span className="block text-[10px] font-semibold text-slate-500 uppercase">Ciclo Estimado</span>
                <span className="text-base font-extrabold text-slate-200 font-mono">{diasCultivoEstimados} días</span>
                <span className="block text-[9px] text-slate-500 mt-0.5">({(diasCultivoEstimados / 30).toFixed(1)} meses)</span>
              </div>
              <div className="text-center md:text-left">
                <span className="block text-[10px] font-semibold text-slate-500 uppercase">Eficiencia (FCR)</span>
                <span className="text-base font-extrabold text-emerald-400 font-mono">{fcr}</span>
                <span className="block text-[9px] text-slate-500 mt-0.5">Conversión ideal</span>
              </div>
            </div>
          </div>

          {/* Comparative card */}
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6">
            <h3 className="text-sm font-bold text-slate-400 uppercase tracking-wider mb-4 flex items-center gap-2">
              <Info className="w-4 h-4 text-blue-400" />
              Comparativa Biológica Rápida (Bajo mismos parámetros)
            </h3>
            <p className="text-xs text-slate-500 mb-4">Estimaciones de rendimiento final manteniendo el mismo tamaño de estanque ({size} {workUnit}).</p>

            <div className="space-y-3.5">
              {speciesList.map((spec) => {
                const specOrgsHarvest = Math.round((spec.density * size) * (spec.survivalRate / 100));
                const specBiomassFinal = (specOrgsHarvest * spec.harvestWeight) / 1000;
                const specFeed = specBiomassFinal * spec.fcr;
                const specCost = specFeed * spec.feedPrice;
                const specRevenue = specBiomassFinal * spec.sellPrice;
                const specProfit = specRevenue - specCost;

                return (
                  <div key={spec.id} className="flex items-center justify-between p-3 bg-slate-950/55 rounded-xl border border-slate-800/40">
                    <div className="flex items-center gap-2">
                      <span className="text-xl">{spec.emoji}</span>
                      <div>
                        <p className="text-sm font-bold text-slate-200">{spec.name}</p>
                        <p className="text-[9px] text-slate-500 font-mono">Densidad: {spec.density}/{spec.workUnit}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-5">
                      <div className="text-right">
                        <span className="block text-[9px] text-slate-500 uppercase">Cosecha Est.</span>
                        <span className="text-xs font-bold text-slate-300">{specBiomassFinal.toLocaleString(undefined, { maximumFractionDigits: 0 })} kg</span>
                      </div>
                      <div className="text-right">
                        <span className="block text-[9px] text-slate-500 uppercase">Utilidad Est.</span>
                        <span className="text-xs font-bold text-emerald-400">${specProfit.toLocaleString(undefined, { maximumFractionDigits: 0 })} USD</span>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
