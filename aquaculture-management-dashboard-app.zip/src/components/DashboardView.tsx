import React from 'react';
import { Pond, Species, LogEntry, calculatePondMetrics, getSpeciesThresholds, getStatus } from '../utils/aquacultureCalculations';
import { Scale, DollarSign, Activity, AlertTriangle, ArrowUpRight, TrendingUp, Layers, Sparkles } from 'lucide-react';

interface DashboardViewProps {
  ponds: Pond[];
  speciesList: Species[];
  logs: LogEntry[];
  setActiveTab: (tab: string) => void;
  setSelectedPondId: (id: string | null) => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  ponds,
  speciesList,
  logs,
  setActiveTab,
  setSelectedPondId
}) => {
  // Calculate combined statistics
  let totalBiomasaActual = 0;
  let totalBiomasaProyectada = 0;
  let totalUtilidadEstimada = 0;
  let totalOrganismos = 0;
  let totalAlertas = 0;

  const pondDetails = ponds.map((pond) => {
    const species = speciesList.find((s) => s.id === pond.speciesId) || speciesList[0];
    const metrics = calculatePondMetrics(pond, species, logs);
    
    totalBiomasaActual += metrics.biomasaActualKg;
    totalBiomasaProyectada += metrics.biomasaFinalKg;
    totalUtilidadEstimada += metrics.utilidadEstimadaUsd;
    totalOrganismos += metrics.totalOrganismsCurrent;

    // Find the latest log for water quality alert checking
    const pondLogs = logs
      .filter((l) => l.pondId === pond.id)
      .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
    
    const latestLog = pondLogs[0];
    let wqStatus: 'optimo' | 'precaucion' | 'critico' = 'optimo';
    let wqAlertsCount = 0;

    if (latestLog && latestLog.waterQuality) {
      const wq = latestLog.waterQuality;
      const thresholds = getSpeciesThresholds(pond.speciesId);
      
      const indicators = [
        { val: wq.oxygen, range: thresholds.oxygen },
        { val: wq.temperature, range: thresholds.temperature },
        { val: wq.ph, range: thresholds.ph },
        { val: wq.ammonium, range: thresholds.ammonium },
        { val: wq.nitrite, range: thresholds.nitrite },
        { val: wq.nitrate, range: thresholds.nitrate },
        { val: wq.salinity, range: thresholds.salinity }
      ];

      indicators.forEach((ind) => {
        const status = getStatus(ind.val, ind.range);
        if (status === 'critico') {
          wqAlertsCount += 2;
        } else if (status === 'precaucion') {
          wqAlertsCount += 1;
        }
      });

      if (wqAlertsCount >= 3) wqStatus = 'critico';
      else if (wqAlertsCount >= 1) wqStatus = 'precaucion';
      
      totalAlertas += wqAlertsCount;
    }

    return {
      pond,
      species,
      metrics,
      wqStatus,
      latestLog
    };
  });

  const handlePondClick = (pondId: string) => {
    setSelectedPondId(pondId);
    setActiveTab('estanques');
  };

  return (
    <div className="space-y-8">
      {/* Top Header Banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-gradient-to-r from-slate-900 via-slate-900/60 to-emerald-950/20 p-6 border border-slate-800 rounded-3xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-emerald-500/5 rounded-full blur-3xl pointer-events-none -mr-20 -mt-20" />
        <div className="space-y-1 z-10">
          <div className="flex items-center gap-2.5">
            <Sparkles className="w-5 h-5 text-emerald-400" />
            <span className="text-xs font-semibold tracking-widest text-emerald-400 uppercase">General Real-Time</span>
          </div>
          <h2 className="text-2xl md:text-3xl font-extrabold tracking-tight text-slate-100">
            Dashboard de Operaciones
          </h2>
          <p className="text-sm text-slate-400">
            Consolidación biológica, parámetros zootécnicos y proyecciones financieras de sus cultivos.
          </p>
        </div>
        <div className="flex items-center gap-3 z-10">
          <button
            onClick={() => setActiveTab('bitacora')}
            className="px-4 py-2 bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200 text-sm font-bold rounded-xl transition duration-200 cursor-pointer"
          >
            Registrar Bitácora
          </button>
          <button
            onClick={() => handlePondClick('')}
            className="px-4 py-2 bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 text-slate-950 text-sm font-bold rounded-xl shadow-lg shadow-emerald-500/10 hover:shadow-emerald-400/20 hover:-translate-y-0.5 active:translate-y-0 transition duration-200 cursor-pointer"
          >
            Nuevo Estanque
          </button>
        </div>
      </div>

      {/* KPI Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
        {/* BIOMASA TOTAL */}
        <div className="bg-slate-900/90 border border-slate-800 p-6 rounded-2xl relative group hover:border-slate-700 transition-colors">
          <div className="flex justify-between items-start">
            <div className="space-y-1">
              <p className="text-xs font-bold tracking-wider text-slate-500 uppercase">Biomasa Total</p>
              <p className="text-2xl md:text-3xl font-extrabold text-slate-100 tracking-tight">
                {totalBiomasaActual.toLocaleString(undefined, { maximumFractionDigits: 1 })}
                <span className="text-sm font-medium text-slate-500 ml-1">kg</span>
              </p>
            </div>
            <div className="p-3 bg-emerald-500/10 border border-emerald-500/20 rounded-xl text-emerald-400 group-hover:scale-105 transition-transform">
              <Scale className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-4 flex items-center gap-1.5 text-[11px] text-slate-400 font-semibold">
            <span className="text-emerald-400 flex items-center gap-0.5 bg-emerald-500/10 px-1.5 py-0.5 rounded">
              <TrendingUp className="w-3.5 h-3.5" /> Activa
            </span>
            <span>en {ponds.length} estanques activos</span>
          </div>
        </div>

        {/* PRODUCCION PROYECTADA */}
        <div className="bg-slate-900/90 border border-slate-800 p-6 rounded-2xl relative group hover:border-slate-700 transition-colors">
          <div className="flex justify-between items-start">
            <div className="space-y-1">
              <p className="text-xs font-bold tracking-wider text-slate-500 uppercase">Cosecha Proyectada</p>
              <p className="text-2xl md:text-3xl font-extrabold text-slate-100 tracking-tight">
                {totalBiomasaProyectada.toLocaleString(undefined, { maximumFractionDigits: 1 })}
                <span className="text-sm font-medium text-slate-500 ml-1">kg</span>
              </p>
            </div>
            <div className="p-3 bg-blue-500/10 border border-blue-500/20 rounded-xl text-blue-400 group-hover:scale-105 transition-transform">
              <Activity className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-4 flex items-center gap-1.5 text-[11px] text-slate-400 font-semibold">
            <span className="text-blue-400 flex items-center gap-0.5 bg-blue-500/10 px-1.5 py-0.5 rounded">
              <ArrowUpRight className="w-3.5 h-3.5" /> Estimado
            </span>
            <span>a peso de cosecha ideal</span>
          </div>
        </div>

        {/* UTILIDAD ESTIMADA */}
        <div className="bg-slate-900/90 border border-slate-800 p-6 rounded-2xl relative group hover:border-slate-700 transition-colors">
          <div className="flex justify-between items-start">
            <div className="space-y-1">
              <p className="text-xs font-bold tracking-wider text-slate-500 uppercase">Utilidad Estimada</p>
              <p className="text-2xl md:text-3xl font-extrabold text-emerald-400 tracking-tight">
                ${totalUtilidadEstimada.toLocaleString(undefined, { maximumFractionDigits: 0 })}
                <span className="text-sm font-medium text-emerald-600 ml-0.5">USD</span>
              </p>
            </div>
            <div className="p-3 bg-emerald-500/10 border border-emerald-500/20 rounded-xl text-emerald-400 group-hover:scale-105 transition-transform">
              <DollarSign className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-4 flex items-center gap-1.5 text-[11px] text-slate-400 font-semibold">
            <span className="text-emerald-400 flex items-center gap-0.5 bg-emerald-500/10 px-1.5 py-0.5 rounded">
              Margen alto
            </span>
            <span>Descontando alimento</span>
          </div>
        </div>

        {/* ALERTAS DE CALIDAD */}
        <div className="bg-slate-900/90 border border-slate-800 p-6 rounded-2xl relative group hover:border-slate-700 transition-colors">
          <div className="flex justify-between items-start">
            <div className="space-y-1">
              <p className="text-xs font-bold tracking-wider text-slate-500 uppercase">Alertas de Calidad</p>
              <p className={`text-2xl md:text-3xl font-extrabold tracking-tight ${totalAlertas > 0 ? 'text-amber-400' : 'text-slate-100'}`}>
                {totalAlertas}
                <span className="text-xs font-medium text-slate-500 ml-1">activas</span>
              </p>
            </div>
            <div className={`p-3 border rounded-xl group-hover:scale-105 transition-transform ${
              totalAlertas > 0
                ? 'bg-amber-500/10 border-amber-500/20 text-amber-400 animate-pulse'
                : 'bg-slate-800 border-slate-700 text-slate-400'
            }`}>
              <AlertTriangle className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-4 flex items-center gap-1.5 text-[11px] text-slate-400 font-semibold">
            <span className={`px-1.5 py-0.5 rounded ${totalAlertas > 0 ? 'bg-amber-500/10 text-amber-400' : 'bg-emerald-500/10 text-emerald-400'}`}>
              {totalAlertas > 0 ? 'Acción sugerida' : 'Sistema Estable'}
            </span>
            <span>basado en últimas bitácoras</span>
          </div>
        </div>
      </div>

      {/* Main Grid Layout: Ponds list + Alerts panel */}
      <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
        {/* Active Ponds Table */}
        <div className="xl:col-span-2 bg-slate-900 border border-slate-800 rounded-2xl p-6">
          <div className="flex justify-between items-center mb-6">
            <div>
              <h3 className="text-lg font-bold text-slate-100 flex items-center gap-2">
                <Layers className="w-4 h-4 text-emerald-400" />
                Resumen de Estanques Activos
              </h3>
              <p className="text-xs text-slate-500">Haga clic en un estanque para ver detalles y gráficos de crecimiento.</p>
            </div>
          </div>

          {ponds.length === 0 ? (
            <div className="text-center py-10 border border-dashed border-slate-800 rounded-xl">
              <Layers className="w-10 h-10 text-slate-700 mx-auto mb-3" />
              <p className="text-sm text-slate-400">No hay estanques registrados.</p>
              <button
                onClick={() => handlePondClick('')}
                className="mt-3 text-xs font-bold text-emerald-400 hover:text-emerald-300 transition"
              >
                Agregar su primer estanque +
              </button>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="border-b border-slate-800 text-[11px] font-bold tracking-wider text-slate-500 uppercase">
                    <th className="pb-3 pl-1">Estanque</th>
                    <th className="pb-3">Especie</th>
                    <th className="pb-3">Población</th>
                    <th className="pb-3">Biomasa</th>
                    <th className="pb-3">SGR</th>
                    <th className="pb-3">FCR Real</th>
                    <th className="pb-3 pr-1 text-right">Calidad</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60">
                  {pondDetails.map(({ pond, species, metrics, wqStatus }) => (
                    <tr
                      key={pond.id}
                      onClick={() => handlePondClick(pond.id)}
                      className="group hover:bg-slate-800/40 cursor-pointer transition duration-150 text-sm"
                    >
                      <td className="py-3.5 pl-1">
                        <div className="font-bold text-slate-200 group-hover:text-emerald-400 transition-colors">
                          {pond.name}
                        </div>
                        <span className="text-[11px] text-slate-500">Siembra: {pond.stockingDate}</span>
                      </td>
                      <td className="py-3.5">
                        <div className="flex items-center gap-1.5">
                          <span className="text-lg">{species.emoji}</span>
                          <div>
                            <p className="font-medium text-slate-300">{species.name}</p>
                            <p className="text-[10px] text-slate-500 italic">{species.scientificName}</p>
                          </div>
                        </div>
                      </td>
                      <td className="py-3.5 font-medium text-slate-300">
                        {metrics.totalOrganismsCurrent.toLocaleString()}
                        <span className="block text-[10px] text-slate-500">Sobrev. {metrics.supervivenciaPorcentaje.toFixed(0)}%</span>
                      </td>
                      <td className="py-3.5">
                        <span className="font-bold text-slate-200">{metrics.biomasaActualKg.toLocaleString(undefined, { maximumFractionDigits: 0 })} kg</span>
                        <span className="block text-[10px] text-slate-500">{pond.currentWeight || metrics.gpdReal} g prom.</span>
                      </td>
                      <td className="py-3.5 text-slate-300 font-mono">{metrics.sgr.toFixed(2)}%</td>
                      <td className="py-3.5">
                        <span className={`font-bold px-2 py-0.5 rounded-full text-xs ${
                          metrics.fcrReal <= species.fcr
                            ? 'bg-emerald-500/10 text-emerald-400'
                            : metrics.fcrReal <= species.fcr + 0.3
                            ? 'bg-amber-500/10 text-amber-400'
                            : 'bg-rose-500/10 text-rose-400'
                        }`}>
                          {metrics.fcrReal > 0 ? metrics.fcrReal : 'N/D'}
                        </span>
                      </td>
                      <td className="py-3.5 pr-1 text-right">
                        <span className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold ${
                          wqStatus === 'optimo'
                            ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                            : wqStatus === 'precaucion'
                            ? 'bg-amber-500/10 text-amber-400 border border-amber-500/20'
                            : 'bg-rose-500/10 text-rose-400 border border-rose-500/20'
                        }`}>
                          <span className={`w-1.5 h-1.5 rounded-full ${
                            wqStatus === 'optimo' ? 'bg-emerald-400' : wqStatus === 'precaucion' ? 'bg-amber-400' : 'bg-rose-400'
                          }`} />
                          {wqStatus.charAt(0).toUpperCase() + wqStatus.slice(1)}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>

        {/* Technical Alerts & Quick actions Column */}
        <div className="space-y-6">
          {/* Water Quality Warning Panel */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6">
            <h3 className="text-lg font-bold text-slate-100 flex items-center gap-2 mb-4">
              <AlertTriangle className="w-4 h-4 text-amber-400" />
              Alertas Biológicas y Químicas
            </h3>

            {totalAlertas === 0 ? (
              <div className="py-6 text-center border border-dashed border-slate-800 rounded-xl">
                <Activity className="w-8 h-8 text-slate-600 mx-auto mb-2" />
                <p className="text-xs text-slate-400 font-medium">Todos los parámetros físico-químicos están en rangos óptimos.</p>
              </div>
            ) : (
              <div className="space-y-3 max-h-64 overflow-y-auto pr-1 scrollbar-thin">
                {pondDetails.map(({ pond, latestLog, species }) => {
                  if (!latestLog || !latestLog.waterQuality) return null;
                  
                  const wq = latestLog.waterQuality;
                  const thresholds = getSpeciesThresholds(pond.speciesId);
                  const alerts: { label: string; val: number; status: 'precaucion' | 'critico'; range: string }[] = [];

                  const checkVal = (val: number, range: any, label: string, unit: string) => {
                    const status = getStatus(val, range);
                    if (status !== 'optimo') {
                      alerts.push({
                        label,
                        val,
                        status,
                        range: `${range.minOpt}-${range.maxOpt} ${unit}`
                      });
                    }
                  };

                  checkVal(wq.oxygen, thresholds.oxygen, 'Oxígeno Disuelto', 'mg/L');
                  checkVal(wq.temperature, thresholds.temperature, 'Temperatura', '°C');
                  checkVal(wq.ph, thresholds.ph, 'pH', '');
                  checkVal(wq.ammonium, thresholds.ammonium, 'Amonio', 'mg/L');
                  checkVal(wq.nitrite, thresholds.nitrite, 'Nitrito', 'mg/L');
                  checkVal(wq.nitrate, thresholds.nitrate, 'Nitrato', 'mg/L');

                  if (alerts.length === 0) return null;

                  return (
                    <div key={pond.id} className="p-3 bg-slate-950/60 border border-slate-800/80 rounded-xl">
                      <p className="text-xs font-bold text-slate-300 flex items-center gap-1.5">
                        <span>{species.emoji}</span> {pond.name}
                      </p>
                      <div className="mt-2 space-y-1.5">
                        {alerts.map((alert, idx) => (
                          <div key={idx} className="flex justify-between items-center text-[11px]">
                            <span className="text-slate-500 font-medium">{alert.label}</span>
                            <div className="flex items-center gap-2">
                              <span className={`font-bold ${alert.status === 'critico' ? 'text-rose-400' : 'text-amber-400'}`}>
                                {alert.val}
                              </span>
                              <span className="text-slate-600 font-mono">({alert.range})</span>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {/* System Statistics card */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6">
            <h3 className="text-sm font-bold text-slate-400 uppercase tracking-wider mb-4">Resumen Biológico</h3>
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <span className="text-xs text-slate-500 font-medium">Población Total Estimada:</span>
                <span className="text-sm font-bold text-slate-200">{totalOrganismos.toLocaleString()} organismos</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-xs text-slate-500 font-medium">Eficiencia Promedio (FCR):</span>
                <span className="text-sm font-bold text-emerald-400">
                  {(pondDetails.reduce((sum, p) => sum + p.metrics.fcrReal, 0) / (ponds.length || 1)).toFixed(2)}
                </span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-xs text-slate-500 font-medium">Especies Activas:</span>
                <span className="text-sm font-bold text-slate-200">
                  {Array.from(new Set(ponds.map(p => p.speciesId))).length} especies
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
