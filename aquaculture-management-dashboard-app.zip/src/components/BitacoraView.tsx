import React, { useState } from 'react';
import { Pond, Species, LogEntry, WaterQuality } from '../utils/aquacultureCalculations';
import { BookOpen, Plus, Search, Trash2, Calendar, MessageSquare, Activity, ChevronDown, ChevronUp, FileSpreadsheet } from 'lucide-react';
import confetti from 'canvas-confetti';

interface BitacoraViewProps {
  ponds: Pond[];
  speciesList: Species[];
  logs: LogEntry[];
  onSaveLog: (log: LogEntry) => void;
  onDeleteLog: (id: string) => void;
}

export const BitacoraView: React.FC<BitacoraViewProps> = ({
  ponds,
  speciesList,
  logs,
  onSaveLog,
  onDeleteLog
}) => {
  const [showAddForm, setShowAddForm] = useState(false);
  const [expandedLogId, setExpandedLogId] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterPondId, setFilterPondId] = useState('');

  // Form States
  const [pondId, setPondId] = useState(ponds[0]?.id || '');
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [feedAmount, setFeedAmount] = useState(10);
  const [mortalities, setMortalities] = useState(0);
  const [avgWeightSample, setAvgWeightSample] = useState<number | undefined>(undefined);
  const [uniformity, setUniformity] = useState<number | undefined>(undefined);
  const [cv, setCv] = useState<number | undefined>(undefined);
  const [observations, setObservations] = useState('');

  // Water Quality Form States (Optional)
  const [includeWq, setIncludeWq] = useState(false);
  const [oxygen, setOxygen] = useState(5.5);
  const [temperature, setTemperature] = useState(27.0);
  const [ph, setPh] = useState(7.2);
  const [ammonium, setAmmonium] = useState(0.02);
  const [nitrite, setNitrite] = useState(0.05);
  const [nitrate, setNitrate] = useState(15.0);
  const [alkalinity, setAlkalinity] = useState(110);
  const [hardness, setHardness] = useState(140);
  const [salinity, setSalinity] = useState(0);
  const [transparency, setTransparency] = useState(30);

  const handleAddLog = (e: React.FormEvent) => {
    e.preventDefault();
    if (!pondId) {
      alert('Por favor, registre y seleccione un estanque antes de crear una bitácora.');
      return;
    }

    const selectedPond = ponds.find((p) => p.id === pondId);
    if (!selectedPond) return;
    const spec = speciesList.find((s) => s.id === selectedPond.speciesId) || speciesList[0];

    let wqData: WaterQuality | undefined = undefined;
    if (includeWq) {
      wqData = {
        oxygen,
        temperature,
        ph,
        ammonium,
        nitrite,
        nitrate,
        alkalinity,
        hardness,
        salinity,
        transparency
      };
    }

    const newLog: LogEntry = {
      id: `log-${Date.now()}`,
      date,
      pondId,
      speciesName: spec.name,
      feedAmount,
      mortalities,
      avgWeightSample,
      uniformity,
      cv,
      waterQuality: wqData,
      observations
    };

    onSaveLog(newLog);
    confetti({ particleCount: 60, spread: 40 });
    
    // Reset
    setFeedAmount(10);
    setMortalities(0);
    setAvgWeightSample(undefined);
    setUniformity(undefined);
    setCv(undefined);
    setObservations('');
    setIncludeWq(false);
    setShowAddForm(false);
  };

  // Filters and Sort
  const filteredLogs = logs
    .filter((l) => {
      const pond = ponds.find((p) => p.id === l.pondId);
      const pondName = pond ? pond.name.toLowerCase() : '';
      const matchSearch = pondName.includes(searchTerm.toLowerCase()) || l.observations.toLowerCase().includes(searchTerm.toLowerCase());
      const matchPond = filterPondId ? l.pondId === filterPondId : true;
      return matchSearch && matchPond;
    })
    .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

  const toggleExpand = (id: string) => {
    setExpandedLogId(expandedLogId === id ? null : id);
  };

  return (
    <div className="space-y-8">
      {/* Header Banner */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-2xl md:text-3xl font-extrabold tracking-tight text-slate-100 flex items-center gap-2.5">
            <BookOpen className="w-8 h-8 text-emerald-400" />
            Bitácora de Campo
          </h2>
          <p className="text-sm text-slate-400">Bitácora operativa de nutrición, muestreos, mortalidades y calidad de agua.</p>
        </div>
        {ponds.length > 0 && (
          <button
            onClick={() => setShowAddForm(!showAddForm)}
            className="px-4 py-2 bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 text-slate-950 text-sm font-bold rounded-xl flex items-center gap-2 shadow-lg shadow-emerald-500/10 hover:shadow-emerald-400/20 hover:-translate-y-0.5 active:translate-y-0 transition duration-200 cursor-pointer"
          >
            <Plus className="w-4.5 h-4.5" />
            Nuevo Registro
          </button>
        )}
      </div>

      {/* Log Addition Form */}
      {showAddForm && (
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-2xl">
          <h3 className="text-lg font-bold text-slate-100 mb-5 flex items-center gap-2">
            <FileSpreadsheet className="w-5 h-5 text-emerald-400" />
            Agregar Nuevo Reporte Diario
          </h3>
          
          <form onSubmit={handleAddLog} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-5">
              {/* Pond Select */}
              <div>
                <label className="block text-xs font-bold text-slate-400 uppercase mb-1.5">Estanque</label>
                <select
                  value={pondId}
                  onChange={(e) => setPondId(e.target.value)}
                  required
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-sm text-slate-200 focus:border-emerald-500/50 outline-none"
                >
                  {ponds.map((p) => (
                    <option key={p.id} value={p.id}>
                      {p.name}
                    </option>
                  ))}
                </select>
              </div>

              {/* Date */}
              <div>
                <label className="block text-xs font-bold text-slate-400 uppercase mb-1.5">Fecha del Reporte</label>
                <input
                  type="date"
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                  required
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-sm text-slate-200 focus:border-emerald-500/50 outline-none"
                />
              </div>

              {/* Feed Amount */}
              <div>
                <label className="block text-xs font-bold text-slate-400 uppercase mb-1.5">Alimento Aplicado (kg)</label>
                <input
                  type="number"
                  value={feedAmount}
                  onChange={(e) => setFeedAmount(Number(e.target.value))}
                  min={0}
                  step="any"
                  required
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-sm text-slate-200 focus:border-emerald-500/50 outline-none"
                />
              </div>

              {/* Mortalities */}
              <div>
                <label className="block text-xs font-bold text-slate-400 uppercase mb-1.5">Mortalidad (orgs)</label>
                <input
                  type="number"
                  value={mortalities}
                  onChange={(e) => setMortalities(Number(e.target.value))}
                  min={0}
                  required
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-sm text-slate-200 focus:border-emerald-500/50 outline-none"
                />
              </div>

              {/* Samplings (Optional) */}
              <div>
                <label className="block text-xs font-bold text-slate-400 uppercase mb-1.5">Peso Promedio Muestreo (g)</label>
                <input
                  type="number"
                  value={avgWeightSample === undefined ? '' : avgWeightSample}
                  onChange={(e) => setAvgWeightSample(e.target.value === '' ? undefined : Number(e.target.value))}
                  min={0.01}
                  step="any"
                  placeholder="Opcional"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-sm text-slate-200 focus:border-emerald-500/50 outline-none"
                />
              </div>

              {/* Uniformity */}
              <div>
                <label className="block text-xs font-bold text-slate-400 uppercase mb-1.5">Uniformidad (%)</label>
                <input
                  type="number"
                  value={uniformity === undefined ? '' : uniformity}
                  onChange={(e) => setUniformity(e.target.value === '' ? undefined : Number(e.target.value))}
                  min={1}
                  max={100}
                  placeholder="Opcional (Ej: 85)"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-sm text-slate-200 focus:border-emerald-500/50 outline-none"
                />
              </div>

              {/* CV */}
              <div>
                <label className="block text-xs font-bold text-slate-400 uppercase mb-1.5">Coef. Variación (CV%)</label>
                <input
                  type="number"
                  value={cv === undefined ? '' : cv}
                  onChange={(e) => setCv(e.target.value === '' ? undefined : Number(e.target.value))}
                  min={0.1}
                  step="any"
                  placeholder="Opcional (Ej: 6)"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-sm text-slate-200 focus:border-emerald-500/50 outline-none"
                />
              </div>
            </div>

            {/* Toggle Water Quality */}
            <div className="p-4.5 bg-slate-950/70 border border-slate-800 rounded-2xl">
              <label className="flex items-center gap-2.5 cursor-pointer">
                <input
                  type="checkbox"
                  checked={includeWq}
                  onChange={(e) => setIncludeWq(e.target.checked)}
                  className="w-4 h-4 accent-emerald-500 rounded cursor-pointer"
                />
                <span className="text-sm font-bold text-slate-300">Incluir Parámetros Físico-Químicos (Calidad de Agua)</span>
              </label>

              {includeWq && (
                <div className="grid grid-cols-2 sm:grid-cols-5 gap-4 mt-5 pt-5 border-t border-slate-900">
                  <div>
                    <label className="block text-[10px] font-bold text-slate-500 uppercase mb-1">Oxígeno (mg/L)</label>
                    <input
                      type="number"
                      value={oxygen}
                      onChange={(e) => setOxygen(Number(e.target.value))}
                      step="any"
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl px-2.5 py-1.5 text-xs text-slate-200 font-mono outline-none focus:border-emerald-500/50"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-bold text-slate-500 uppercase mb-1">Temp (°C)</label>
                    <input
                      type="number"
                      value={temperature}
                      onChange={(e) => setTemperature(Number(e.target.value))}
                      step="any"
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl px-2.5 py-1.5 text-xs text-slate-200 font-mono outline-none focus:border-emerald-500/50"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-bold text-slate-500 uppercase mb-1">Nivel pH</label>
                    <input
                      type="number"
                      value={ph}
                      onChange={(e) => setPh(Number(e.target.value))}
                      step="any"
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl px-2.5 py-1.5 text-xs text-slate-200 font-mono outline-none focus:border-emerald-500/50"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-bold text-slate-500 uppercase mb-1">Amonio (mg/L)</label>
                    <input
                      type="number"
                      value={ammonium}
                      onChange={(e) => setAmmonium(Number(e.target.value))}
                      step="any"
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl px-2.5 py-1.5 text-xs text-slate-200 font-mono outline-none focus:border-emerald-500/50"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-bold text-slate-500 uppercase mb-1">Nitrito (mg/L)</label>
                    <input
                      type="number"
                      value={nitrite}
                      onChange={(e) => setNitrite(Number(e.target.value))}
                      step="any"
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl px-2.5 py-1.5 text-xs text-slate-200 font-mono outline-none focus:border-emerald-500/50"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-bold text-slate-500 uppercase mb-1">Nitrato (mg/L)</label>
                    <input
                      type="number"
                      value={nitrate}
                      onChange={(e) => setNitrate(Number(e.target.value))}
                      step="any"
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl px-2.5 py-1.5 text-xs text-slate-200 font-mono outline-none focus:border-emerald-500/50"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-bold text-slate-500 uppercase mb-1">Alcalinidad</label>
                    <input
                      type="number"
                      value={alkalinity}
                      onChange={(e) => setAlkalinity(Number(e.target.value))}
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl px-2.5 py-1.5 text-xs text-slate-200 font-mono outline-none focus:border-emerald-500/50"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-bold text-slate-500 uppercase mb-1">Dureza</label>
                    <input
                      type="number"
                      value={hardness}
                      onChange={(e) => setHardness(Number(e.target.value))}
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl px-2.5 py-1.5 text-xs text-slate-200 font-mono outline-none focus:border-emerald-500/50"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-bold text-slate-500 uppercase mb-1">Salinidad (ppt)</label>
                    <input
                      type="number"
                      value={salinity}
                      onChange={(e) => setSalinity(Number(e.target.value))}
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl px-2.5 py-1.5 text-xs text-slate-200 font-mono outline-none focus:border-emerald-500/50"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-bold text-slate-500 uppercase mb-1">Transparencia</label>
                    <input
                      type="number"
                      value={transparency}
                      onChange={(e) => setTransparency(Number(e.target.value))}
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl px-2.5 py-1.5 text-xs text-slate-200 font-mono outline-none focus:border-emerald-500/50"
                    />
                  </div>
                </div>
              )}
            </div>

            {/* Observations */}
            <div>
              <label className="block text-xs font-bold text-slate-400 uppercase mb-1.5">Observaciones Generales</label>
              <textarea
                value={observations}
                onChange={(e) => setObservations(e.target.value)}
                placeholder="Ej: Consumo de alimento normal. Sin novedades biológicas o físico-químicas."
                rows={3}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-sm text-slate-200 focus:border-emerald-500/50 outline-none resize-none"
              />
            </div>

            {/* Submit / Cancel buttons */}
            <div className="flex justify-end gap-3 pt-2 border-t border-slate-800/60">
              <button
                type="button"
                onClick={() => setShowAddForm(false)}
                className="px-4 py-2 border border-slate-800 text-slate-400 text-sm font-bold rounded-xl hover:bg-slate-800 transition cursor-pointer"
              >
                Cancelar
              </button>
              <button
                type="submit"
                className="px-5 py-2 bg-emerald-500 hover:bg-emerald-400 text-slate-950 text-sm font-bold rounded-xl transition cursor-pointer"
              >
                Guardar Registro
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Filters and Records list */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6">
        <div className="flex flex-col md:flex-row gap-4 justify-between items-center mb-6">
          <h3 className="text-base font-bold text-slate-100 flex items-center gap-2 shrink-0">
            <Calendar className="w-4.5 h-4.5 text-emerald-400" />
            Historial de Registros Operativos
          </h3>

          <div className="flex flex-col sm:flex-row gap-3 w-full md:w-auto">
            {/* Search Bar */}
            <div className="relative flex-1 sm:w-64">
              <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Buscar en observaciones..."
                className="w-full bg-slate-950 border border-slate-800/80 rounded-xl pl-10 pr-4 py-2 text-xs text-slate-200 placeholder-slate-650 focus:border-emerald-500/50 outline-none"
              />
            </div>

            {/* Pond filter */}
            <select
              value={filterPondId}
              onChange={(e) => setFilterPondId(e.target.value)}
              className="bg-slate-950 border border-slate-800/80 text-slate-300 text-xs font-semibold py-2 px-3.5 rounded-xl focus:border-emerald-500/50 outline-none"
            >
              <option value="">Todos los estanques</option>
              {ponds.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.name}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Table */}
        {filteredLogs.length === 0 ? (
          <div className="text-center py-10 border border-dashed border-slate-850 rounded-2xl">
            <BookOpen className="w-10 h-10 text-slate-700 mx-auto mb-3" />
            <p className="text-sm text-slate-400">No hay registros de bitácora que coincidan con los filtros.</p>
          </div>
        ) : (
          <div className="space-y-4">
            {filteredLogs.map((log) => {
              const pond = ponds.find((p) => p.id === log.pondId);
              const isExpanded = expandedLogId === log.id;
              
              return (
                <div
                  key={log.id}
                  className="bg-slate-950/40 border border-slate-800 rounded-2xl overflow-hidden transition hover:border-slate-700"
                >
                  {/* Compact row */}
                  <div
                    onClick={() => toggleExpand(log.id)}
                    className="p-4 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 cursor-pointer select-none"
                  >
                    <div className="flex items-center gap-3.5">
                      <div className="p-2 bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 rounded-xl shrink-0">
                        <Calendar className="w-4.5 h-4.5" />
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-slate-200 text-sm">{pond ? pond.name : 'Estanque Eliminado'}</span>
                          <span className="text-[10px] bg-slate-800 border border-slate-700 text-slate-400 px-2 py-0.5 rounded-full uppercase font-semibold tracking-wider">
                            {log.speciesName}
                          </span>
                        </div>
                        <span className="text-xs text-slate-500 font-mono">{log.date}</span>
                      </div>
                    </div>

                    <div className="flex items-center gap-6 w-full sm:w-auto justify-between sm:justify-end text-xs">
                      <div className="text-right">
                        <span className="text-slate-500 block font-semibold">Alimento</span>
                        <span className="font-bold text-slate-300 font-mono">{log.feedAmount} kg</span>
                      </div>
                      <div className="text-right">
                        <span className="text-slate-500 block font-semibold">Mortalidad</span>
                        <span className="font-bold text-rose-400 font-mono">{log.mortalities} org</span>
                      </div>
                      <div className="text-right">
                        <span className="text-slate-500 block font-semibold">Muestreo (Peso)</span>
                        <span className="font-bold text-slate-300 font-mono">{log.avgWeightSample ? `${log.avgWeightSample} g` : 'N/D'}</span>
                      </div>
                      <button className="p-1.5 hover:bg-slate-800 rounded-lg text-slate-400 transition shrink-0">
                        {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                      </button>
                    </div>
                  </div>

                  {/* Expanded Details */}
                  {isExpanded && (
                    <div className="px-5 pb-5 pt-3 border-t border-slate-900 bg-slate-950/90 space-y-4 text-xs">
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
                        {/* Observations */}
                        <div className="md:col-span-2 space-y-1">
                          <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider flex items-center gap-1">
                            <MessageSquare className="w-3.5 h-3.5 text-slate-500" /> Observaciones
                          </span>
                          <p className="text-slate-300 bg-slate-900 border border-slate-800 rounded-xl p-3 leading-relaxed font-medium">
                            {log.observations || 'Sin observaciones registradas.'}
                          </p>
                        </div>

                        {/* Actions / deletion */}
                        <div className="flex flex-col justify-between items-end bg-slate-900/30 border border-slate-800/40 rounded-xl p-3.5">
                          <div className="w-full space-y-2">
                            <div className="flex justify-between items-center text-[10px] text-slate-500 uppercase font-bold">
                              <span>Uniformidad</span>
                              <span className="text-slate-300 font-mono">{log.uniformity ? `${log.uniformity}%` : 'N/D'}</span>
                            </div>
                            <div className="flex justify-between items-center text-[10px] text-slate-500 uppercase font-bold">
                              <span>Coef. Var (CV)</span>
                              <span className="text-slate-300 font-mono">{log.cv ? `${log.cv}%` : 'N/D'}</span>
                            </div>
                          </div>
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              if (confirm('¿Está seguro de eliminar esta bitácora de manera permanente?')) {
                                onDeleteLog(log.id);
                              }
                            }}
                            className="mt-3 px-3 py-1.5 bg-rose-500/10 border border-rose-500/25 text-rose-400 hover:bg-rose-500/20 font-bold rounded-lg flex items-center gap-1.5 transition cursor-pointer"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                            Eliminar Reporte
                          </button>
                        </div>
                      </div>

                      {/* Water Quality sub-table */}
                      {log.waterQuality && (
                        <div className="space-y-2">
                          <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider flex items-center gap-1">
                            <Activity className="w-3.5 h-3.5 text-slate-500" /> Mediciones Químicas (Calidad de Agua)
                          </span>
                          <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 bg-slate-900 border border-slate-800 rounded-xl p-3">
                            <div>
                              <span className="text-slate-500 block font-semibold">Oxígeno Disuelto:</span>
                              <span className="font-bold text-slate-200 font-mono">{log.waterQuality.oxygen} mg/L</span>
                            </div>
                            <div>
                              <span className="text-slate-500 block font-semibold">Temperatura:</span>
                              <span className="font-bold text-slate-200 font-mono">{log.waterQuality.temperature} °C</span>
                            </div>
                            <div>
                              <span className="text-slate-500 block font-semibold">Nivel de pH:</span>
                              <span className="font-bold text-slate-200 font-mono">{log.waterQuality.ph}</span>
                            </div>
                            <div>
                              <span className="text-slate-500 block font-semibold">Amonio (NH4+):</span>
                              <span className="font-bold text-slate-200 font-mono">{log.waterQuality.ammonium} mg/L</span>
                            </div>
                            <div>
                              <span className="text-slate-500 block font-semibold">Nitrito (NO2-):</span>
                              <span className="font-bold text-slate-200 font-mono">{log.waterQuality.nitrite} mg/L</span>
                            </div>
                            <div>
                              <span className="text-slate-500 block font-semibold">Nitrato (NO3-):</span>
                              <span className="font-bold text-slate-200 font-mono">{log.waterQuality.nitrate} mg/L</span>
                            </div>
                            <div>
                              <span className="text-slate-500 block font-semibold">Alcalinidad:</span>
                              <span className="font-bold text-slate-200 font-mono">{log.waterQuality.alkalinity} mg/L</span>
                            </div>
                            <div>
                              <span className="text-slate-500 block font-semibold">Dureza Total:</span>
                              <span className="font-bold text-slate-200 font-mono">{log.waterQuality.hardness} mg/L</span>
                            </div>
                            <div>
                              <span className="text-slate-500 block font-semibold">Salinidad:</span>
                              <span className="font-bold text-slate-200 font-mono">{log.waterQuality.salinity} ppt</span>
                            </div>
                            <div>
                              <span className="text-slate-500 block font-semibold">Transparencia:</span>
                              <span className="font-bold text-slate-200 font-mono">{log.waterQuality.transparency} cm</span>
                            </div>
                          </div>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
