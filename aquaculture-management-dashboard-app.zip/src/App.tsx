import React, { useState, useEffect } from 'react';
import { authService, dataService, AppUser, initFirebase, getSavedFirebaseConfig } from './utils/firebaseService';
import { Species, Pond, LogEntry, PRECONFIGURED_SPECIES } from './utils/aquacultureCalculations';
import { AuthModal } from './components/AuthModal';
import { Sidebar } from './components/Sidebar';
import { DashboardView } from './components/DashboardView';
import { PondsView } from './components/PondsView';
import { CalculadoraView } from './components/CalculadoraView';
import { EspeciesView } from './components/EspeciesView';
import { WaterQualityView } from './components/WaterQualityView';
import { BitacoraView } from './components/BitacoraView';
import { ReportesView } from './components/ReportesView';
import { AjustesView } from './components/AjustesView';
import { Fish } from 'lucide-react';

export const App: React.FC = () => {
  const [user, setUser] = useState<AppUser | null>(null);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('dashboard');
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  // Database states
  const [customSpecies, setCustomSpecies] = useState<Species[]>([]);
  const [ponds, setPonds] = useState<Pond[]>([]);
  const [logs, setLogs] = useState<LogEntry[]>([]);
  const [selectedPondId, setSelectedPondId] = useState<string | null>(null);

  // Combined species list: Preconfigured + Custom
  const speciesList = [...PRECONFIGURED_SPECIES, ...customSpecies];

  // Load initial user session
  useEffect(() => {
    const checkUser = async () => {
      try {
        const currentUser = await authService.getCurrentUser();
        setUser(currentUser);
      } catch (e) {
        console.error('Error checking user session:', e);
      } finally {
        setLoading(false);
      }
    };
    checkUser();
  }, []);

  // Load user data once authenticated
  const loadUserData = async (uid: string) => {
    try {
      const cSpec = await dataService.getCustomSpecies(uid);
      const cPonds = await dataService.getPonds(uid);
      const cLogs = await dataService.getLogs(uid);

      setCustomSpecies(cSpec);
      setPonds(cPonds);
      setLogs(cLogs);
      
      if (cPonds.length > 0 && !selectedPondId) {
        setSelectedPondId(cPonds[0].id);
      }
    } catch (err) {
      console.error('Error loading user database:', err);
    }
  };

  useEffect(() => {
    if (user) {
      loadUserData(user.uid);
    }
  }, [user]);

  // Database Actions
  const handleSavePond = async (pond: Pond) => {
    if (!user) return;
    await dataService.savePond(user.uid, pond);
    // Refresh
    const cPonds = await dataService.getPonds(user.uid);
    setPonds(cPonds);
  };

  const handleDeletePond = async (pondId: string) => {
    if (!user) return;
    await dataService.deletePond(user.uid, pondId);
    // Refresh
    const cPonds = await dataService.getPonds(user.uid);
    const cLogs = await dataService.getLogs(user.uid);
    setPonds(cPonds);
    setLogs(cLogs);
  };

  const handleSaveLog = async (log: LogEntry) => {
    if (!user) return;
    await dataService.saveLog(user.uid, log);
    // Refresh
    const cLogs = await dataService.getLogs(user.uid);
    setLogs(cLogs);
  };

  const handleDeleteLog = async (logId: string) => {
    if (!user) return;
    await dataService.deleteLog(user.uid, logId);
    // Refresh
    const cLogs = await dataService.getLogs(user.uid);
    setLogs(cLogs);
  };

  const handleSaveSpecies = async (species: Species) => {
    if (!user) return;
    const updatedCustom = [...customSpecies, species];
    await dataService.saveCustomSpecies(user.uid, updatedCustom);
    setCustomSpecies(updatedCustom);
  };

  const handleDeleteSpecies = async (id: string) => {
    if (!user) return;
    const updatedCustom = customSpecies.filter((s) => s.id !== id);
    await dataService.saveCustomSpecies(user.uid, updatedCustom);
    setCustomSpecies(updatedCustom);
  };

  const handleResetAllData = async () => {
    if (!user) return;
    // Clear localStorage
    localStorage.removeItem('PRUEBA_01_MOCK_PONDS');
    localStorage.removeItem('PRUEBA_01_MOCK_LOGS');
    localStorage.removeItem('PRUEBA_01_MOCK_SPECIES');
    // Reload
    await loadUserData(user.uid);
  };

  const handleResetSpecies = async () => {
    if (!user) return;
    await dataService.saveCustomSpecies(user.uid, []);
    setCustomSpecies([]);
  };

  const handleFirebaseConfigChange = () => {
    const savedConfig = getSavedFirebaseConfig();
    if (savedConfig) {
      initFirebase(savedConfig);
    }
    if (user) {
      loadUserData(user.uid);
    }
  };

  const handleLogout = async () => {
    await authService.logout();
    setUser(null);
    setSelectedPondId(null);
    setPonds([]);
    setLogs([]);
    setCustomSpecies([]);
  };

  if (loading) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-slate-950 text-slate-300">
        <div className="relative flex items-center justify-center mb-4">
          <div className="absolute w-16 h-16 border-4 border-emerald-500/20 border-t-emerald-400 rounded-full animate-spin" />
          <Fish className="w-8 h-8 text-emerald-400" />
        </div>
        <p className="text-sm font-semibold tracking-wider text-slate-500 animate-pulse">
          Cargando Plataforma Acuícola...
        </p>
      </div>
    );
  }

  if (!user) {
    return <AuthModal onAuthSuccess={(u) => setUser(u)} />;
  }

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col lg:flex-row">
      {/* Sidebar Navigation */}
      <Sidebar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        user={user}
        onLogout={handleLogout}
        isMobileOpen={isMobileMenuOpen}
        setIsMobileOpen={setIsMobileMenuOpen}
      />

      {/* Main Viewport */}
      <main className="flex-1 min-w-0 overflow-x-hidden pt-16 lg:pt-0 px-4 sm:px-6 lg:px-8 py-8">
        <div className="max-w-7xl mx-auto print:px-0 print:py-0">
          {activeTab === 'dashboard' && (
            <DashboardView
              ponds={ponds}
              speciesList={speciesList}
              logs={logs}
              setActiveTab={setActiveTab}
              setSelectedPondId={setSelectedPondId}
            />
          )}

          {activeTab === 'estanques' && (
            <PondsView
              ponds={ponds}
              speciesList={speciesList}
              logs={logs}
              onSavePond={handleSavePond}
              onDeletePond={handleDeletePond}
              selectedPondId={selectedPondId}
              setSelectedPondId={setSelectedPondId}
            />
          )}

          {activeTab === 'calculadora' && (
            <CalculadoraView speciesList={speciesList} />
          )}

          {activeTab === 'especies' && (
            <EspeciesView
              speciesList={speciesList}
              onSaveSpecies={handleSaveSpecies}
              onDeleteSpecies={handleDeleteSpecies}
              onResetToDefault={handleResetSpecies}
            />
          )}

          {activeTab === 'calidad' && (
            <WaterQualityView ponds={ponds} speciesList={speciesList} logs={logs} />
          )}

          {activeTab === 'bitacora' && (
            <BitacoraView
              ponds={ponds}
              speciesList={speciesList}
              logs={logs}
              onSaveLog={handleSaveLog}
              onDeleteLog={handleDeleteLog}
            />
          )}

          {activeTab === 'reportes' && (
            <ReportesView ponds={ponds} speciesList={speciesList} logs={logs} />
          )}

          {activeTab === 'ajustes' && (
            <AjustesView
              onResetAllData={handleResetAllData}
              onFirebaseConfigChange={handleFirebaseConfigChange}
            />
          )}
        </div>
      </main>
    </div>
  );
};

export default App;
