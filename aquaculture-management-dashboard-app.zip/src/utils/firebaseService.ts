import { initializeApp, getApp, getApps, FirebaseApp } from 'firebase/app';
import {
  getAuth,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  sendPasswordResetEmail,
  signOut,
  GoogleAuthProvider,
  signInWithPopup,
  Auth
} from 'firebase/auth';
import {
  getFirestore,
  collection,
  doc,
  setDoc,
  getDocs,
  deleteDoc,
  query,
  where,
  Firestore
} from 'firebase/firestore';
import { Species, Pond, LogEntry } from './aquacultureCalculations';

export interface FirebaseConfigData {
  apiKey: string;
  authDomain: string;
  projectId: string;
  storageBucket: string;
  messagingSenderId: string;
  appId: string;
}

export interface AppUser {
  uid: string;
  email: string;
  displayName: string;
  photoURL?: string;
  role?: string;
}

let firebaseApp: FirebaseApp | null = null;
let authInstance: Auth | null = null;
let dbInstance: Firestore | null = null;

// Load custom Firebase config if saved in localStorage
export const getSavedFirebaseConfig = (): FirebaseConfigData | null => {
  const saved = localStorage.getItem('PRUEBA_01_FIREBASE_CONFIG');
  if (saved) {
    try {
      return JSON.parse(saved);
    } catch (e) {
      return null;
    }
  }
  return null;
};

export const saveFirebaseConfig = (config: FirebaseConfigData | null) => {
  if (config) {
    localStorage.setItem('PRUEBA_01_FIREBASE_CONFIG', JSON.stringify(config));
  } else {
    localStorage.removeItem('PRUEBA_01_FIREBASE_CONFIG');
  }
};

export const isFirebaseConnected = (): boolean => {
  return firebaseApp !== null;
};

export const initFirebase = (config: FirebaseConfigData): boolean => {
  try {
    if (getApps().length > 0) {
      // App already initialized, retrieve it
      firebaseApp = getApp();
    } else {
      firebaseApp = initializeApp(config);
    }
    authInstance = getAuth(firebaseApp);
    dbInstance = getFirestore(firebaseApp);
    return true;
  } catch (error) {
    console.error('Error initializing Firebase:', error);
    firebaseApp = null;
    authInstance = null;
    dbInstance = null;
    return false;
  }
};

// Try to auto-init on load
const savedConfig = getSavedFirebaseConfig();
if (savedConfig) {
  initFirebase(savedConfig);
}

// Seed Data for Mock fallback
const MOCK_SPECIES_KEY = 'PRUEBA_01_MOCK_SPECIES';
const MOCK_PONDS_KEY = 'PRUEBA_01_MOCK_PONDS';
const MOCK_LOGS_KEY = 'PRUEBA_01_MOCK_LOGS';
const MOCK_USER_KEY = 'PRUEBA_01_MOCK_USER';

const SEED_SPECIES: Species[] = []; // Custom species added by user, initially empty (max 3)

const SEED_PONDS: Pond[] = [
  {
    id: 'pond-1',
    name: 'Estanque R-1 (Tilapia)',
    area: 1200,
    volume: 1800,
    speciesId: 'tilapia',
    stockingDate: new Date(Date.now() - 95 * 24 * 60 * 60 * 1000).toISOString().split('T')[0], // 95 days ago
    density: 12,
    initialWeight: 5,
    currentWeight: 185,
    survivalRate: 88,
    mortalidadesAcumuladas: 140,
    alimentacionAcumulada: 2250,
    uniformity: 85,
    cv: 7.5
  },
  {
    id: 'pond-2',
    name: 'Estanque T-4 (Trucha)',
    area: 500,
    volume: 1000,
    speciesId: 'trucha',
    stockingDate: new Date(Date.now() - 60 * 24 * 60 * 60 * 1000).toISOString().split('T')[0], // 60 days ago
    density: 20,
    initialWeight: 10,
    currentWeight: 145,
    survivalRate: 92,
    mortalidadesAcumuladas: 120,
    alimentacionAcumulada: 1950,
    uniformity: 90,
    cv: 5.2
  },
  {
    id: 'pond-3',
    name: 'Estanque C-12 (Camarón)',
    area: 2500,
    volume: 3000,
    speciesId: 'camaron',
    stockingDate: new Date(Date.now() - 45 * 24 * 60 * 60 * 1000).toISOString().split('T')[0], // 45 days ago
    density: 35,
    initialWeight: 0.1,
    currentWeight: 9.8,
    survivalRate: 79,
    mortalidadesAcumuladas: 3500,
    alimentacionAcumulada: 680,
    uniformity: 78,
    cv: 12.4
  }
];

// Create 5 dummy log entries for history
const generateMockLogs = (): LogEntry[] => {
  const logs: LogEntry[] = [];
  const dates = [90, 60, 30, 15, 2]; // days ago
  
  // Tilapia Logs
  dates.forEach((daysAgo, idx) => {
    const logDate = new Date(Date.now() - daysAgo * 24 * 60 * 60 * 1000).toISOString().split('T')[0];
    logs.push({
      id: `log-tilapia-${idx}`,
      date: logDate,
      pondId: 'pond-1',
      speciesName: 'Tilapia',
      feedAmount: 150 + (idx * 60),
      mortalities: Math.floor(Math.random() * 20) + 5,
      avgWeightSample: 15 + (idx * 40),
      waterQuality: {
        oxygen: 6.2 - (idx * 0.2),
        temperature: 27.5 + (idx * 0.3),
        ph: 7.4 + (idx * 0.1),
        ammonium: 0.02 + (idx * 0.01),
        nitrite: 0.05 + (idx * 0.02),
        nitrate: 12 + (idx * 3),
        alkalinity: 110,
        hardness: 150,
        salinity: 2,
        transparency: 32 - idx
      },
      uniformity: 80 + idx,
      cv: 9 - (idx * 0.4),
      observations: `Muestreo de rutina y control de calidad de agua. Biomasa y crecimiento óptimo.`
    });
  });

  // Trucha Logs
  dates.forEach((daysAgo, idx) => {
    const logDate = new Date(Date.now() - daysAgo * 24 * 60 * 60 * 1000).toISOString().split('T')[0];
    logs.push({
      id: `log-trucha-${idx}`,
      date: logDate,
      pondId: 'pond-2',
      speciesName: 'Trucha Arcoíris',
      feedAmount: 180 + (idx * 70),
      mortalities: Math.floor(Math.random() * 15) + 3,
      avgWeightSample: 25 + (idx * 30),
      waterQuality: {
        oxygen: 8.5 - (idx * 0.15),
        temperature: 13.8 + (idx * 0.2),
        ph: 7.2 - (idx * 0.05),
        ammonium: 0.005 + (idx * 0.005),
        nitrite: 0.01 + (idx * 0.005),
        nitrate: 5 + (idx * 1.5),
        alkalinity: 90,
        hardness: 120,
        salinity: 0,
        transparency: 45 - idx * 2
      },
      uniformity: 85 + idx,
      cv: 6.5 - (idx * 0.3),
      observations: `Monitoreo de oxigenación y alimentación. Parámetros estables.`
    });
  });

  return logs;
};

// Helper to initialize LocalStorage values
const getOrInitMockData = <T>(key: string, defaultData: T): T => {
  const data = localStorage.getItem(key);
  if (!data) {
    localStorage.setItem(key, JSON.stringify(defaultData));
    return defaultData;
  }
  try {
    return JSON.parse(data);
  } catch (e) {
    return defaultData;
  }
};

// In Mock Mode, our data is stored in LocalStorage and auto-saved
let mockPonds: Pond[] = getOrInitMockData(MOCK_PONDS_KEY, SEED_PONDS);
let mockLogs: LogEntry[] = getOrInitMockData(MOCK_LOGS_KEY, generateMockLogs());
let mockCustomSpecies: Species[] = getOrInitMockData(MOCK_SPECIES_KEY, SEED_SPECIES);

// AUTHENTICATION LAYER
export interface AuthResponse {
  user: AppUser | null;
  error?: string;
}

export const authService = {
  async getCurrentUser(): Promise<AppUser | null> {
    if (authInstance) {
      const firebaseUser = authInstance.currentUser;
      if (firebaseUser) {
        return {
          uid: firebaseUser.uid,
          email: firebaseUser.email || '',
          displayName: firebaseUser.displayName || 'Usuario de Firebase',
          photoURL: firebaseUser.photoURL || undefined
        };
      }
    }
    const localUser = localStorage.getItem(MOCK_USER_KEY);
    if (localUser) {
      try {
        return JSON.parse(localUser);
      } catch (e) {
        return null;
      }
    }
    return null;
  },

  async loginWithEmail(email: string, password: string): Promise<AuthResponse> {
    if (authInstance) {
      try {
        const userCredential = await signInWithEmailAndPassword(authInstance, email, password);
        const user = userCredential.user;
        const appUser: AppUser = {
          uid: user.uid,
          email: user.email || '',
          displayName: user.displayName || email.split('@')[0],
          photoURL: user.photoURL || undefined
        };
        return { user: appUser };
      } catch (e: any) {
        return { user: null, error: e.message || 'Error de autenticación' };
      }
    }

    // Mock authentication
    if (email && password.length >= 6) {
      const user: AppUser = {
        uid: 'mock-uid-123',
        email: email,
        displayName: email.split('@')[0].toUpperCase(),
        photoURL: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150'
      };
      localStorage.setItem(MOCK_USER_KEY, JSON.stringify(user));
      return { user };
    }
    return { user: null, error: 'La contraseña debe tener al menos 6 caracteres.' };
  },

  async registerWithEmail(email: string, password: string, displayName: string): Promise<AuthResponse> {
    if (authInstance) {
      try {
        const userCredential = await createUserWithEmailAndPassword(authInstance, email, password);
        const user = userCredential.user;
        const appUser: AppUser = {
          uid: user.uid,
          email: user.email || '',
          displayName: displayName || email.split('@')[0],
          photoURL: undefined
        };
        // Store profile info in firestore if possible
        if (dbInstance) {
          await setDoc(doc(dbInstance, 'users', user.uid), {
            email,
            displayName,
            createdAt: new Date().toISOString()
          });
        }
        return { user: appUser };
      } catch (e: any) {
        return { user: null, error: e.message || 'Error al registrar usuario' };
      }
    }

    // Mock registration
    if (email && password.length >= 6) {
      const user: AppUser = {
        uid: 'mock-uid-123',
        email: email,
        displayName: displayName || email.split('@')[0].toUpperCase(),
        photoURL: 'https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?w=150'
      };
      localStorage.setItem(MOCK_USER_KEY, JSON.stringify(user));
      return { user };
    }
    return { user: null, error: 'Error al registrar. Asegúrese de usar un correo válido y contraseña >= 6 caracteres.' };
  },

  async loginWithGoogle(): Promise<AuthResponse> {
    if (authInstance) {
      try {
        const provider = new GoogleAuthProvider();
        const userCredential = await signInWithPopup(authInstance, provider);
        const user = userCredential.user;
        const appUser: AppUser = {
          uid: user.uid,
          email: user.email || '',
          displayName: user.displayName || 'Usuario Google',
          photoURL: user.photoURL || undefined
        };
        return { user: appUser };
      } catch (e: any) {
        return { user: null, error: e.message || 'Error de autenticación con Google' };
      }
    }

    // Mock Google login
    const user: AppUser = {
      uid: 'mock-google-uid',
      email: 'acuicultor.demo@gmail.com',
      displayName: 'Dr. Carlos Mendoza (Demo)',
      photoURL: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150'
    };
    localStorage.setItem(MOCK_USER_KEY, JSON.stringify(user));
    return { user };
  },

  async recoverPassword(email: string): Promise<{ success: boolean; error?: string }> {
    if (authInstance) {
      try {
        await sendPasswordResetEmail(authInstance, email);
        return { success: true };
      } catch (e: any) {
        return { success: false, error: e.message || 'Error al enviar correo de recuperación' };
      }
    }
    // Mock recover
    if (email.includes('@')) {
      return { success: true };
    }
    return { success: false, error: 'Ingrese un correo electrónico válido.' };
  },

  async logout(): Promise<void> {
    if (authInstance) {
      await signOut(authInstance);
    }
    localStorage.removeItem(MOCK_USER_KEY);
  },

  async updateProfile(displayName: string, photoURL?: string): Promise<AppUser | null> {
    const currentUser = await this.getCurrentUser();
    if (!currentUser) return null;

    const updated: AppUser = {
      ...currentUser,
      displayName,
      photoURL: photoURL || currentUser.photoURL
    };

    // Save updated mock user
    localStorage.setItem(MOCK_USER_KEY, JSON.stringify(updated));

    if (authInstance && authInstance.currentUser) {
      // We can't easily update authInstance profile here without full firebase auth imports, but we support it mock-wise
    }

    return updated;
  }
};

// DATA STORAGE LAYER
export const dataService = {
  // custom species (Max 3 custom species)
  async getCustomSpecies(userId: string): Promise<Species[]> {
    if (dbInstance && userId) {
      try {
        const q = query(collection(dbInstance, 'customSpecies'), where('userId', '==', userId));
        const querySnapshot = await getDocs(q);
        const list: Species[] = [];
        querySnapshot.forEach((doc) => {
          list.push({ id: doc.id, ...doc.data() } as Species);
        });
        return list;
      } catch (e) {
        console.error('Firestore read failed, using localStorage: ', e);
      }
    }
    mockCustomSpecies = getOrInitMockData(MOCK_SPECIES_KEY, SEED_SPECIES);
    return mockCustomSpecies;
  },

  async saveCustomSpecies(userId: string, speciesList: Species[]): Promise<void> {
    if (dbInstance && userId) {
      try {
        // Delete existing custom species and rewrite
        const q = query(collection(dbInstance, 'customSpecies'), where('userId', '==', userId));
        const querySnapshot = await getDocs(q);
        for (const document of querySnapshot.docs) {
          await deleteDoc(doc(dbInstance, 'customSpecies', document.id));
        }
        for (const s of speciesList) {
          await setDoc(doc(dbInstance, 'customSpecies', s.id), {
            ...s,
            userId
          });
        }
        return;
      } catch (e) {
        console.error('Firestore save failed, saving locally: ', e);
      }
    }
    mockCustomSpecies = speciesList;
    localStorage.setItem(MOCK_SPECIES_KEY, JSON.stringify(speciesList));
  },

  // Ponds
  async getPonds(userId: string): Promise<Pond[]> {
    if (dbInstance && userId) {
      try {
        const q = query(collection(dbInstance, 'ponds'), where('userId', '==', userId));
        const querySnapshot = await getDocs(q);
        const list: Pond[] = [];
        querySnapshot.forEach((doc) => {
          list.push({ id: doc.id, ...doc.data() } as Pond);
        });
        if (list.length > 0) {
          return list;
        }
      } catch (e) {
        console.error('Firestore read failed, using localStorage: ', e);
      }
    }
    mockPonds = getOrInitMockData(MOCK_PONDS_KEY, SEED_PONDS);
    return mockPonds;
  },

  async savePond(userId: string, pond: Pond): Promise<void> {
    if (dbInstance && userId) {
      try {
        await setDoc(doc(dbInstance, 'ponds', pond.id), {
          ...pond,
          userId,
          updatedAt: new Date().toISOString()
        });
        return;
      } catch (e) {
        console.error('Firestore save failed, saving locally: ', e);
      }
    }
    const idx = mockPonds.findIndex((p) => p.id === pond.id);
    if (idx > -1) {
      mockPonds[idx] = pond;
    } else {
      mockPonds.push(pond);
    }
    localStorage.setItem(MOCK_PONDS_KEY, JSON.stringify(mockPonds));
  },

  async deletePond(userId: string, pondId: string): Promise<void> {
    if (dbInstance && userId) {
      try {
        await deleteDoc(doc(dbInstance, 'ponds', pondId));
        return;
      } catch (e) {
        console.error('Firestore delete failed, deleting locally: ', e);
      }
    }
    mockPonds = mockPonds.filter((p) => p.id !== pondId);
    localStorage.setItem(MOCK_PONDS_KEY, JSON.stringify(mockPonds));

    // also clean up logs for this pond
    mockLogs = mockLogs.filter((l) => l.pondId !== pondId);
    localStorage.setItem(MOCK_LOGS_KEY, JSON.stringify(mockLogs));
  },

  // Logs
  async getLogs(userId: string): Promise<LogEntry[]> {
    if (dbInstance && userId) {
      try {
        const q = query(collection(dbInstance, 'logs'), where('userId', '==', userId));
        const querySnapshot = await getDocs(q);
        const list: LogEntry[] = [];
        querySnapshot.forEach((doc) => {
          list.push({ id: doc.id, ...doc.data() } as LogEntry);
        });
        if (list.length > 0) {
          return list;
        }
      } catch (e) {
        console.error('Firestore read failed, using localStorage: ', e);
      }
    }
    mockLogs = getOrInitMockData(MOCK_LOGS_KEY, generateMockLogs());
    return mockLogs;
  },

  async saveLog(userId: string, log: LogEntry): Promise<void> {
    if (dbInstance && userId) {
      try {
        await setDoc(doc(dbInstance, 'logs', log.id), {
          ...log,
          userId,
          updatedAt: new Date().toISOString()
        });
        return;
      } catch (e) {
        console.error('Firestore save failed, saving locally: ', e);
      }
    }
    const idx = mockLogs.findIndex((l) => l.id === log.id);
    if (idx > -1) {
      mockLogs[idx] = log;
    } else {
      mockLogs.push(log);
    }
    localStorage.setItem(MOCK_LOGS_KEY, JSON.stringify(mockLogs));
  },

  async deleteLog(userId: string, logId: string): Promise<void> {
    if (dbInstance && userId) {
      try {
        await deleteDoc(doc(dbInstance, 'logs', logId));
        return;
      } catch (e) {
        console.error('Firestore delete failed, deleting locally: ', e);
      }
    }
    mockLogs = mockLogs.filter((l) => l.id !== logId);
    localStorage.setItem(MOCK_LOGS_KEY, JSON.stringify(mockLogs));
  }
};
