export interface Species {
  id: string;
  name: string;
  scientificName: string;
  emoji: string;
  density: number; // organisms per unit
  survivalRate: number; // % (e.g. 85)
  fcr: number; // Feed Conversion Ratio (e.g. 1.5)
  feedRate: number; // % of biomass fed per day (e.g. 3%)
  feedingsPerDay: number;
  gpd: number; // growth per day in grams
  feedPrice: number; // USD per kg
  sellPrice: number; // USD per kg
  initialWeight: number; // grams
  harvestWeight: number; // grams
  workUnit: 'm²' | 'm³';
  isCustom?: boolean;
}

export interface Pond {
  id: string;
  name: string;
  area: number;
  volume: number;
  speciesId: string;
  stockingDate: string; // YYYY-MM-DD
  density: number; // organisms/unit
  initialWeight: number; // grams
  currentWeight?: number; // grams
  survivalRate?: number; // current % estimation
  mortalidadesAcumuladas: number;
  alimentacionAcumulada: number; // kg
  uniformity?: number; // %
  cv?: number; // CV%
}

export interface WaterQuality {
  oxygen: number; // mg/L
  temperature: number; // °C
  ph: number;
  ammonium: number; // mg/L (NH4+)
  nitrite: number; // mg/L (NO2-)
  nitrate: number; // mg/L (NO3-)
  alkalinity: number; // mg/L
  hardness: number; // mg/L
  salinity: number; // ppt
  transparency: number; // cm
}

export interface LogEntry {
  id: string;
  date: string;
  pondId: string;
  speciesName: string;
  feedAmount: number; // kg
  mortalities: number;
  avgWeightSample?: number; // grams
  waterQuality?: WaterQuality;
  uniformity?: number; // %
  cv?: number; // %
  observations: string;
}

// Preconfigured Species
export const PRECONFIGURED_SPECIES: Species[] = [
  {
    id: 'tilapia',
    name: 'Tilapia',
    scientificName: 'Oreochromis niloticus',
    emoji: '🐟',
    density: 15, // per m²
    survivalRate: 85,
    fcr: 1.3,
    feedRate: 3.0,
    feedingsPerDay: 3,
    gpd: 1.8,
    feedPrice: 1.2,
    sellPrice: 4.5,
    initialWeight: 5,
    harvestWeight: 500,
    workUnit: 'm²',
    isCustom: false
  },
  {
    id: 'trucha',
    name: 'Trucha Arcoíris',
    scientificName: 'Oncorhynchus mykiss',
    emoji: '🐟',
    density: 25, // per m³
    survivalRate: 90,
    fcr: 1.1,
    feedRate: 2.5,
    feedingsPerDay: 4,
    gpd: 2.2,
    feedPrice: 1.5,
    sellPrice: 6.8,
    initialWeight: 10,
    harvestWeight: 350,
    workUnit: 'm³',
    isCustom: false
  },
  {
    id: 'camaron',
    name: 'Camarón Blanco',
    scientificName: 'Litopenaeus vannamei',
    emoji: '🦐',
    density: 30, // per m²
    survivalRate: 75,
    fcr: 1.4,
    feedRate: 4.0,
    feedingsPerDay: 5,
    gpd: 0.25,
    feedPrice: 1.4,
    sellPrice: 8.5,
    initialWeight: 0.1,
    harvestWeight: 20,
    workUnit: 'm²',
    isCustom: false
  },
  {
    id: 'guapote',
    name: 'Guapote Tigre',
    scientificName: 'Parachromis managuensis',
    emoji: '🐠',
    density: 5, // per m²
    survivalRate: 80,
    fcr: 1.7,
    feedRate: 3.5,
    feedingsPerDay: 2,
    gpd: 1.2,
    feedPrice: 1.1,
    sellPrice: 5.0,
    initialWeight: 8,
    harvestWeight: 450,
    workUnit: 'm²',
    isCustom: false
  },
  {
    id: 'pangasio',
    name: 'Pangasio',
    scientificName: 'Pangasianodon hypophthalmus',
    emoji: '🦈',
    density: 20, // per m³
    survivalRate: 88,
    fcr: 1.5,
    feedRate: 2.8,
    feedingsPerDay: 2,
    gpd: 2.5,
    feedPrice: 1.0,
    sellPrice: 3.8,
    initialWeight: 15,
    harvestWeight: 1000,
    workUnit: 'm³',
    isCustom: false
  }
];

// Water Quality Optimal Ranges for alert checking
export interface Range {
  minOpt: number;
  maxOpt: number;
  minWarn: number;
  maxWarn: number;
}

export interface WaterQualityThresholds {
  oxygen: Range;
  temperature: Range;
  ph: Range;
  ammonium: Range;
  nitrite: Range;
  nitrate: Range;
  alkalinity: Range;
  hardness: Range;
  salinity: Range;
  transparency: Range;
}

export const DEFAULT_THRESHOLDS: Record<string, WaterQualityThresholds> = {
  tilapia: {
    oxygen: { minOpt: 5, maxOpt: 8, minWarn: 3, maxWarn: 12 },
    temperature: { minOpt: 26, maxOpt: 30, minWarn: 20, maxWarn: 34 },
    ph: { minOpt: 6.5, maxOpt: 8.5, minWarn: 5.5, maxWarn: 9.5 },
    ammonium: { minOpt: 0, maxOpt: 0.05, minWarn: 0.05, maxWarn: 0.2 },
    nitrite: { minOpt: 0, maxOpt: 0.1, minWarn: 0.1, maxWarn: 0.5 },
    nitrate: { minOpt: 0, maxOpt: 40, minWarn: 40, maxWarn: 100 },
    alkalinity: { minOpt: 80, maxOpt: 150, minWarn: 40, maxWarn: 250 },
    hardness: { minOpt: 100, maxOpt: 200, minWarn: 50, maxWarn: 350 },
    salinity: { minOpt: 0, maxOpt: 5, minWarn: 0, maxWarn: 15 },
    transparency: { minOpt: 25, maxOpt: 35, minWarn: 15, maxWarn: 50 }
  },
  trucha: {
    oxygen: { minOpt: 7, maxOpt: 10, minWarn: 5.5, maxWarn: 14 },
    temperature: { minOpt: 12, maxOpt: 16, minWarn: 8, maxWarn: 20 },
    ph: { minOpt: 6.8, maxOpt: 7.8, minWarn: 6.0, maxWarn: 8.5 },
    ammonium: { minOpt: 0, maxOpt: 0.01, minWarn: 0.01, maxWarn: 0.05 },
    nitrite: { minOpt: 0, maxOpt: 0.02, minWarn: 0.02, maxWarn: 0.1 },
    nitrate: { minOpt: 0, maxOpt: 20, minWarn: 20, maxWarn: 50 },
    alkalinity: { minOpt: 60, maxOpt: 120, minWarn: 30, maxWarn: 200 },
    hardness: { minOpt: 80, maxOpt: 150, minWarn: 40, maxWarn: 250 },
    salinity: { minOpt: 0, maxOpt: 2, minWarn: 0, maxWarn: 10 },
    transparency: { minOpt: 30, maxOpt: 50, minWarn: 20, maxWarn: 80 }
  },
  camaron: {
    oxygen: { minOpt: 4.5, maxOpt: 7, minWarn: 3, maxWarn: 10 },
    temperature: { minOpt: 28, maxOpt: 32, minWarn: 22, maxWarn: 35 },
    ph: { minOpt: 7.5, maxOpt: 8.5, minWarn: 7.0, maxWarn: 9.0 },
    ammonium: { minOpt: 0, maxOpt: 0.1, minWarn: 0.1, maxWarn: 0.5 },
    nitrite: { minOpt: 0, maxOpt: 0.5, minWarn: 0.5, maxWarn: 1.5 },
    nitrate: { minOpt: 0, maxOpt: 50, minWarn: 50, maxWarn: 150 },
    alkalinity: { minOpt: 100, maxOpt: 180, minWarn: 80, maxWarn: 220 },
    hardness: { minOpt: 150, maxOpt: 300, minWarn: 100, maxWarn: 500 },
    salinity: { minOpt: 15, maxOpt: 28, minWarn: 5, maxWarn: 35 },
    transparency: { minOpt: 30, maxOpt: 40, minWarn: 20, maxWarn: 60 }
  },
  guapote: {
    oxygen: { minOpt: 4.5, maxOpt: 7.5, minWarn: 3, maxWarn: 10 },
    temperature: { minOpt: 24, maxOpt: 28, minWarn: 18, maxWarn: 32 },
    ph: { minOpt: 6.8, maxOpt: 8.2, minWarn: 6.0, maxWarn: 9.0 },
    ammonium: { minOpt: 0, maxOpt: 0.05, minWarn: 0.05, maxWarn: 0.2 },
    nitrite: { minOpt: 0, maxOpt: 0.1, minWarn: 0.1, maxWarn: 0.5 },
    nitrate: { minOpt: 0, maxOpt: 30, minWarn: 30, maxWarn: 80 },
    alkalinity: { minOpt: 80, maxOpt: 140, minWarn: 50, maxWarn: 200 },
    hardness: { minOpt: 90, maxOpt: 180, minWarn: 50, maxWarn: 300 },
    salinity: { minOpt: 0, maxOpt: 4, minWarn: 0, maxWarn: 10 },
    transparency: { minOpt: 25, maxOpt: 40, minWarn: 15, maxWarn: 60 }
  },
  pangasio: {
    oxygen: { minOpt: 3.5, maxOpt: 6.5, minWarn: 2, maxWarn: 9 },
    temperature: { minOpt: 26, maxOpt: 31, minWarn: 22, maxWarn: 34 },
    ph: { minOpt: 6.5, maxOpt: 8.0, minWarn: 5.5, maxWarn: 9.0 },
    ammonium: { minOpt: 0, maxOpt: 0.1, minWarn: 0.1, maxWarn: 0.5 },
    nitrite: { minOpt: 0, maxOpt: 0.2, minWarn: 0.2, maxWarn: 0.8 },
    nitrate: { minOpt: 0, maxOpt: 50, minWarn: 50, maxWarn: 120 },
    alkalinity: { minOpt: 70, maxOpt: 130, minWarn: 40, maxWarn: 200 },
    hardness: { minOpt: 80, maxOpt: 170, minWarn: 40, maxWarn: 280 },
    salinity: { minOpt: 0, maxOpt: 2, minWarn: 0, maxWarn: 8 },
    transparency: { minOpt: 20, maxOpt: 35, minWarn: 12, maxWarn: 50 }
  }
};

export const getStatus = (value: number, range: Range): 'optimo' | 'precaucion' | 'critico' => {
  if (value >= range.minOpt && value <= range.maxOpt) {
    return 'optimo';
  }
  if (value >= range.minWarn && value <= range.maxWarn) {
    return 'precaucion';
  }
  return 'critico';
};

export const getSpeciesThresholds = (speciesId: string): WaterQualityThresholds => {
  // Return standard thresholds or default tilapia for custom species
  return DEFAULT_THRESHOLDS[speciesId] || DEFAULT_THRESHOLDS['tilapia'];
};

export interface ProductionMetrics {
  totalOrganismsInitial: number;
  totalOrganismsCurrent: number;
  biomasaInicialKg: number;
  biomasaActualKg: number;
  biomasaFinalKg: number;
  supervivenciaPorcentaje: number;
  mortalidadPorcentaje: number;
  gananciaBiomasaKg: number;
  alimentoTotalKg: number;
  fcrTeorico: number;
  fcrReal: number;
  costoAlimentoUsd: number;
  ingresoBrutoUsd: number;
  utilidadEstimadaUsd: number;
  productividadArea: number; // kg/m² or kg/m³
  diasCultivo: number;
  sgr: number; // %/day
  gpdReal: number; // g/day
}

// Calculates the metrics for a single pond
export function calculatePondMetrics(
  pond: Pond,
  species: Species,
  logs: LogEntry[]
): ProductionMetrics {
  // Filter logs for this pond
  const pondLogs = logs
    .filter((log) => log.pondId === pond.id)
    .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());

  // Days since stocking
  const stockDate = new Date(pond.stockingDate);
  const today = new Date();
  const diffTime = Math.max(0, today.getTime() - stockDate.getTime());
  const diasCultivo = Math.max(1, Math.ceil(diffTime / (1000 * 60 * 60 * 24)));

  // Work unit factor (area or volume)
  const areaOrVolume = species.workUnit === 'm²' ? pond.area : pond.volume;
  const totalOrganismsInitial = Math.round(pond.density * areaOrVolume);

  // Sum mortalities from logs, or fallback to pond.mortalidadesAcumuladas
  const totalMortalitiesLogged = pondLogs.reduce((sum, l) => sum + (l.mortalities || 0), 0);
  const currentMortalidades = Math.max(pond.mortalidadesAcumuladas, totalMortalitiesLogged);
  const totalOrganismsCurrent = Math.max(0, totalOrganismsInitial - currentMortalidades);

  // Supervivencia & Mortalidad
  const supervivenciaPorcentaje = totalOrganismsInitial > 0
    ? (totalOrganismsCurrent / totalOrganismsInitial) * 100
    : 0;
  const mortalidadPorcentaje = 100 - supervivenciaPorcentaje;

  // Weight details
  const weightInit = pond.initialWeight || species.initialWeight || 1;
  
  // Last sample weight
  const lastSampleWeight = pondLogs.filter(l => l.avgWeightSample !== undefined && l.avgWeightSample > 0).slice(-1)[0]?.avgWeightSample;
  const weightActual = lastSampleWeight || pond.currentWeight || Math.min(species.harvestWeight, weightInit + (species.gpd * diasCultivo));
  const weightFinal = species.harvestWeight;

  // Biomasses
  const biomasaInicialKg = (totalOrganismsInitial * weightInit) / 1000;
  const biomasaActualKg = (totalOrganismsCurrent * weightActual) / 1000;
  const biomasaFinalKg = ((totalOrganismsInitial * (species.survivalRate / 100)) * weightFinal) / 1000;

  const gananciaBiomasaKg = Math.max(0, biomasaActualKg - biomasaInicialKg);

  // Alimento Total (sum from logs or estimation based on theoretical FCR)
  const totalFeedLogged = pondLogs.reduce((sum, l) => sum + (l.feedAmount || 0), 0);
  const alimentoTotalKg = totalFeedLogged > 0 ? totalFeedLogged : (gananciaBiomasaKg * species.fcr);

  // FCRs
  const fcrTeorico = species.fcr;
  const fcrReal = gananciaBiomasaKg > 0 ? (alimentoTotalKg / gananciaBiomasaKg) : 0;

  // Financials
  const costoAlimentoUsd = alimentoTotalKg * species.feedPrice;
  const ingresoBrutoUsd = biomasaActualKg * species.sellPrice;
  const utilidadEstimadaUsd = ingresoBrutoUsd - costoAlimentoUsd;

  // Productividad
  const productividadArea = areaOrVolume > 0 ? biomasaActualKg / areaOrVolume : 0;

  // GPD & SGR
  const gpdReal = diasCultivo > 0 ? (weightActual - weightInit) / diasCultivo : species.gpd;
  const sgr = (diasCultivo > 0 && weightActual > 0 && weightInit > 0)
    ? (Math.log(weightActual / weightInit) / diasCultivo) * 100
    : 0;

  return {
    totalOrganismsInitial,
    totalOrganismsCurrent,
    biomasaInicialKg,
    biomasaActualKg,
    biomasaFinalKg,
    supervivenciaPorcentaje,
    mortalidadPorcentaje,
    gananciaBiomasaKg,
    alimentoTotalKg,
    fcrTeorico,
    fcrReal: parseFloat(fcrReal.toFixed(2)),
    costoAlimentoUsd,
    ingresoBrutoUsd,
    utilidadEstimadaUsd,
    productividadArea: parseFloat(productividadArea.toFixed(3)),
    diasCultivo,
    sgr: parseFloat(sgr.toFixed(2)),
    gpdReal: parseFloat(gpdReal.toFixed(3))
  };
}
